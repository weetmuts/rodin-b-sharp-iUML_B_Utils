/*******************************************************************************
 * Copyright (c) 2011 University of Southampton.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *******************************************************************************/
package layout.navigator;

import java.util.Collections;

import layout.Layout;
import layout.LayoutFactory;

import org.eclipse.core.commands.AbstractHandler;
import org.eclipse.core.commands.ExecutionEvent;
import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IFile;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.AbstractEMFOperation;
import org.eclipse.jface.dialogs.IInputValidator;
import org.eclipse.jface.dialogs.InputDialog;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Display;
import org.eclipse.ui.handlers.HandlerUtil;
import org.eventb.core.IContextRoot;
import org.eventb.emf.core.context.Context;

/**
 * Command handler for adding a new layout to context root.
 * 
 * @author vitaly
 *
 */
public class AddLayoutHandler extends AbstractHandler {

	// name validator
	static final IInputValidator nameValidator = new IInputValidator(){

		@Override
		public String isValid(String name) {
			if (name.trim().isEmpty())
				return "";
			return null;
		}
	};
	
	/**
	 * EMF command for adding a Layout to a context.
	 * 
	 * @author vitaly
	 *
	 */
	public class AddLayoutCommand extends AbstractEMFOperation {

		private URI contextURI;
		private Layout Layout;

		public AddLayoutCommand(URI contextURI, Layout Layout) {
			super(TransactionalEditingDomain.Factory.INSTANCE.createEditingDomain(), "Add Layout");
			this.contextURI = contextURI;
			this.Layout = Layout;
		}

		@Override
		protected IStatus doExecute(IProgressMonitor monitor, IAdaptable info)
				throws ExecutionException {
			monitor.beginTask("Creating Layout", IProgressMonitor.UNKNOWN);
			
			TransactionalEditingDomain editingDomain = getEditingDomain();
			
			try {
				Resource resource = editingDomain.getResourceSet().getResource(contextURI, true);
				
				if (resource != null && resource.isLoaded()) {
					Context context = (Context) resource.getContents().get(0);
					context.getExtensions().add(Layout);
					resource.save(Collections.emptyMap());
				}
			} catch (Exception e) {
				return new Status(Status.ERROR, Activator.PLUGIN_ID, "Failed to add Layout", e);
			} finally {
				monitor.done();
			}
			return Status.OK_STATUS;
		}

	}

	@Override
	public Object execute(ExecutionEvent event) throws ExecutionException {
		ISelection selection = HandlerUtil.getCurrentSelectionChecked(event);
		if (selection instanceof IStructuredSelection) {
			Object element = ((IStructuredSelection) selection).getFirstElement();
			if (element instanceof IContextRoot) {
				IContextRoot contextRoot = (IContextRoot) element;
				IFile file = contextRoot.getResource();
					
				if (file != null && file.exists()) {
					InputDialog dialog = new InputDialog(Display.getCurrent().getActiveShell(), 
							"New Layout", 
							"Enter Layout name: ",
							null, nameValidator);
					if (dialog.open() == InputDialog.CANCEL)
						return null;
					String name = dialog.getValue().trim();
					
					URI contextURI = URI.createPlatformResourceURI(file.getFullPath().toOSString(), true);
					Layout Layout = LayoutFactory.eINSTANCE.createLayout();
					Layout.setName(name);
					try {
						AddLayoutCommand command = new AddLayoutCommand(contextURI, Layout);
						if (command.canExecute())
							command.execute(new NullProgressMonitor(), null);
					} catch (Exception e) {
						//Activator.getDefault().logError("Creating Layout failed", e);
					}
				}
			}
		}
		return null;
	}

}
