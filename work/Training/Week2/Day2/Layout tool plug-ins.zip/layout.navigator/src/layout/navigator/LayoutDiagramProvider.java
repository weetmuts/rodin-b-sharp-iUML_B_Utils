/**
 * Copyright (c) 2011 University of Southampton.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 */
package layout.navigator;

import layout.Layout;
import layout.diagram.edit.parts.LayoutEditPart;
import layout.diagram.part.LayoutDiagramEditor;
import layout.diagram.part.LayoutDiagramEditorPlugin;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.diagram.core.preferences.PreferencesHint;
import org.eventb.emf.core.machine.Machine;

import ac.soton.eventb.emf.diagrams.navigator.provider.IDiagramProvider;


/**
 * Diagram provider for layout.
 * 
 * @author vitaly
 *
 */
public class LayoutDiagramProvider implements IDiagramProvider {

	@Override
	public String getDiagramFileName(EObject element) {
		if (element instanceof Layout) {
			String filename = "";
			Layout rootLayout = (Layout) element;
			
			//construct filename
			filename = rootLayout.getName() + ".layoutDiag";
			// prefix with machine name
			EObject root = EcoreUtil.getRootContainer(element);
			if (root != null && root instanceof Machine)
				filename = ((Machine) root).getName() + "." + filename;
			
			return filename;
		}
		return null;
	}

	@Override
	public PreferencesHint getPreferencesHint() {
		return LayoutDiagramEditorPlugin.DIAGRAM_PREFERENCES_HINT;
	}

	@Override
	public String getDiagramKind() {
		return LayoutEditPart.MODEL_ID;
	}

	@Override
	public String getEditorId() {
		return LayoutDiagramEditor.ID;
	}

}
