/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Crossing</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see layout.LayoutPackage#getCrossing()
 * @model
 * @generated
 */
public interface Crossing extends NODE {
} // Crossing
