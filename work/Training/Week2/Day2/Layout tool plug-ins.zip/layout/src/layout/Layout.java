/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;

import ac.soton.eventb.emf.diagrams.Diagram;

import org.eclipse.emf.common.util.EList;
import org.eventb.emf.core.AbstractExtension;
import org.eventb.emf.core.EventBNamedCommentedElement;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Layout</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link layout.Layout#getNodes <em>Nodes</em>}</li>
 *   <li>{@link layout.Layout#getSegments <em>Segments</em>}</li>
 * </ul>
 * </p>
 *
 * @see layout.LayoutPackage#getLayout()
 * @model
 * @generated
 */
public interface Layout extends EventBNamedCommentedElement, AbstractExtension, Diagram {
	/**
	 * Returns the value of the '<em><b>Nodes</b></em>' containment reference list.
	 * The list contents are of type {@link layout.NODE}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nodes</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nodes</em>' containment reference list.
	 * @see layout.LayoutPackage#getLayout_Nodes()
	 * @model containment="true" resolveProxies="true"
	 * @generated
	 */
	EList<NODE> getNodes();

	/**
	 * Returns the value of the '<em><b>Segments</b></em>' containment reference list.
	 * The list contents are of type {@link layout.SEGMENT}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Segments</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Segments</em>' containment reference list.
	 * @see layout.LayoutPackage#getLayout_Segments()
	 * @model containment="true" resolveProxies="true"
	 * @generated
	 */
	EList<SEGMENT> getSegments();

} // Layout
