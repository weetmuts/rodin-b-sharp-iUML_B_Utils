/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout.impl;

import layout.Connection;
import layout.LayoutPackage;
import layout.SEGMENT;

import org.eclipse.emf.common.notify.Notification;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Connection</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link layout.impl.ConnectionImpl#getP1 <em>P1</em>}</li>
 *   <li>{@link layout.impl.ConnectionImpl#getP2 <em>P2</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class ConnectionImpl extends EObjectImpl implements Connection {
	/**
	 * The cached value of the '{@link #getP1() <em>P1</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getP1()
	 * @generated
	 * @ordered
	 */
	protected SEGMENT p1;

	/**
	 * The cached value of the '{@link #getP2() <em>P2</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getP2()
	 * @generated
	 * @ordered
	 */
	protected SEGMENT p2;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ConnectionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LayoutPackage.Literals.CONNECTION;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT getP1() {
		if (p1 != null && p1.eIsProxy()) {
			InternalEObject oldP1 = (InternalEObject)p1;
			p1 = (SEGMENT)eResolveProxy(oldP1);
			if (p1 != oldP1) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LayoutPackage.CONNECTION__P1, oldP1, p1));
			}
		}
		return p1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT basicGetP1() {
		return p1;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setP1(SEGMENT newP1) {
		SEGMENT oldP1 = p1;
		p1 = newP1;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.CONNECTION__P1, oldP1, p1));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT getP2() {
		if (p2 != null && p2.eIsProxy()) {
			InternalEObject oldP2 = (InternalEObject)p2;
			p2 = (SEGMENT)eResolveProxy(oldP2);
			if (p2 != oldP2) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LayoutPackage.CONNECTION__P2, oldP2, p2));
			}
		}
		return p2;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT basicGetP2() {
		return p2;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setP2(SEGMENT newP2) {
		SEGMENT oldP2 = p2;
		p2 = newP2;
		if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.CONNECTION__P2, oldP2, p2));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case LayoutPackage.CONNECTION__P1:
				if (resolve) return getP1();
				return basicGetP1();
			case LayoutPackage.CONNECTION__P2:
				if (resolve) return getP2();
				return basicGetP2();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case LayoutPackage.CONNECTION__P1:
				setP1((SEGMENT)newValue);
				return;
			case LayoutPackage.CONNECTION__P2:
				setP2((SEGMENT)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case LayoutPackage.CONNECTION__P1:
				setP1((SEGMENT)null);
				return;
			case LayoutPackage.CONNECTION__P2:
				setP2((SEGMENT)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case LayoutPackage.CONNECTION__P1:
				return p1 != null;
			case LayoutPackage.CONNECTION__P2:
				return p2 != null;
		}
		return super.eIsSet(featureID);
	}

} //ConnectionImpl
