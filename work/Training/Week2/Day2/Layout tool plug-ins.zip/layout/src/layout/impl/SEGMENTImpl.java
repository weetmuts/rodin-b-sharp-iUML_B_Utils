/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout.impl;

import layout.LayoutPackage;
import layout.NODE;
import layout.SEGMENT;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eventb.emf.core.impl.EventBNamedCommentedElementImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>SEGMENT</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link layout.impl.SEGMENTImpl#getSEG_dest <em>SEG dest</em>}</li>
 *   <li>{@link layout.impl.SEGMENTImpl#getSEG_src <em>SEG src</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class SEGMENTImpl extends EventBNamedCommentedElementImpl implements SEGMENT {
	/**
	 * The cached value of the '{@link #getSEG_dest() <em>SEG dest</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSEG_dest()
	 * @generated
	 * @ordered
	 */
	protected NODE seG_dest;

	/**
	 * The cached value of the '{@link #getSEG_src() <em>SEG src</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getSEG_src()
	 * @generated
	 * @ordered
	 */
	protected NODE seG_src;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected SEGMENTImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LayoutPackage.Literals.SEGMENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NODE getSEG_dest() {
		if (seG_dest != null && seG_dest.eIsProxy()) {
			InternalEObject oldSEG_dest = (InternalEObject)seG_dest;
			seG_dest = (NODE)eResolveProxy(oldSEG_dest);
			if (seG_dest != oldSEG_dest) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LayoutPackage.SEGMENT__SEG_DEST, oldSEG_dest, seG_dest));
			}
		}
		return seG_dest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NODE basicGetSEG_dest() {
		return seG_dest;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSEG_dest(NODE newSEG_dest, NotificationChain msgs) {
		NODE oldSEG_dest = seG_dest;
		seG_dest = newSEG_dest;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, LayoutPackage.SEGMENT__SEG_DEST, oldSEG_dest, newSEG_dest);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSEG_dest(NODE newSEG_dest) {
		if (newSEG_dest != seG_dest) {
			NotificationChain msgs = null;
			if (seG_dest != null)
				msgs = ((InternalEObject)seG_dest).eInverseRemove(this, LayoutPackage.NODE__INCOMING, NODE.class, msgs);
			if (newSEG_dest != null)
				msgs = ((InternalEObject)newSEG_dest).eInverseAdd(this, LayoutPackage.NODE__INCOMING, NODE.class, msgs);
			msgs = basicSetSEG_dest(newSEG_dest, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.SEGMENT__SEG_DEST, newSEG_dest, newSEG_dest));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NODE getSEG_src() {
		if (seG_src != null && seG_src.eIsProxy()) {
			InternalEObject oldSEG_src = (InternalEObject)seG_src;
			seG_src = (NODE)eResolveProxy(oldSEG_src);
			if (seG_src != oldSEG_src) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LayoutPackage.SEGMENT__SEG_SRC, oldSEG_src, seG_src));
			}
		}
		return seG_src;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NODE basicGetSEG_src() {
		return seG_src;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetSEG_src(NODE newSEG_src, NotificationChain msgs) {
		NODE oldSEG_src = seG_src;
		seG_src = newSEG_src;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, LayoutPackage.SEGMENT__SEG_SRC, oldSEG_src, newSEG_src);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setSEG_src(NODE newSEG_src) {
		if (newSEG_src != seG_src) {
			NotificationChain msgs = null;
			if (seG_src != null)
				msgs = ((InternalEObject)seG_src).eInverseRemove(this, LayoutPackage.NODE__OUTGOING, NODE.class, msgs);
			if (newSEG_src != null)
				msgs = ((InternalEObject)newSEG_src).eInverseAdd(this, LayoutPackage.NODE__OUTGOING, NODE.class, msgs);
			msgs = basicSetSEG_src(newSEG_src, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.SEGMENT__SEG_SRC, newSEG_src, newSEG_src));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case LayoutPackage.SEGMENT__SEG_DEST:
				if (seG_dest != null)
					msgs = ((InternalEObject)seG_dest).eInverseRemove(this, LayoutPackage.NODE__INCOMING, NODE.class, msgs);
				return basicSetSEG_dest((NODE)otherEnd, msgs);
			case LayoutPackage.SEGMENT__SEG_SRC:
				if (seG_src != null)
					msgs = ((InternalEObject)seG_src).eInverseRemove(this, LayoutPackage.NODE__OUTGOING, NODE.class, msgs);
				return basicSetSEG_src((NODE)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case LayoutPackage.SEGMENT__SEG_DEST:
				return basicSetSEG_dest(null, msgs);
			case LayoutPackage.SEGMENT__SEG_SRC:
				return basicSetSEG_src(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case LayoutPackage.SEGMENT__SEG_DEST:
				if (resolve) return getSEG_dest();
				return basicGetSEG_dest();
			case LayoutPackage.SEGMENT__SEG_SRC:
				if (resolve) return getSEG_src();
				return basicGetSEG_src();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case LayoutPackage.SEGMENT__SEG_DEST:
				setSEG_dest((NODE)newValue);
				return;
			case LayoutPackage.SEGMENT__SEG_SRC:
				setSEG_src((NODE)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case LayoutPackage.SEGMENT__SEG_DEST:
				setSEG_dest((NODE)null);
				return;
			case LayoutPackage.SEGMENT__SEG_SRC:
				setSEG_src((NODE)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case LayoutPackage.SEGMENT__SEG_DEST:
				return seG_dest != null;
			case LayoutPackage.SEGMENT__SEG_SRC:
				return seG_src != null;
		}
		return super.eIsSet(featureID);
	}

} //SEGMENTImpl
