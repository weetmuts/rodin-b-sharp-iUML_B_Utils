/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;

import org.eventb.emf.core.EventBNamedCommentedElement;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>SEGMENT</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link layout.SEGMENT#getSEG_dest <em>SEG dest</em>}</li>
 *   <li>{@link layout.SEGMENT#getSEG_src <em>SEG src</em>}</li>
 * </ul>
 * </p>
 *
 * @see layout.LayoutPackage#getSEGMENT()
 * @model
 * @generated
 */
public interface SEGMENT extends EventBNamedCommentedElement {
	/**
	 * Returns the value of the '<em><b>SEG dest</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link layout.NODE#getIncoming <em>Incoming</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SEG dest</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SEG dest</em>' reference.
	 * @see #setSEG_dest(NODE)
	 * @see layout.LayoutPackage#getSEGMENT_SEG_dest()
	 * @see layout.NODE#getIncoming
	 * @model opposite="incoming" required="true"
	 * @generated
	 */
	NODE getSEG_dest();

	/**
	 * Sets the value of the '{@link layout.SEGMENT#getSEG_dest <em>SEG dest</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SEG dest</em>' reference.
	 * @see #getSEG_dest()
	 * @generated
	 */
	void setSEG_dest(NODE value);

	/**
	 * Returns the value of the '<em><b>SEG src</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link layout.NODE#getOutgoing <em>Outgoing</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>SEG src</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>SEG src</em>' reference.
	 * @see #setSEG_src(NODE)
	 * @see layout.LayoutPackage#getSEGMENT_SEG_src()
	 * @see layout.NODE#getOutgoing
	 * @model opposite="outgoing" required="true"
	 * @generated
	 */
	NODE getSEG_src();

	/**
	 * Sets the value of the '{@link layout.SEGMENT#getSEG_src <em>SEG src</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>SEG src</em>' reference.
	 * @see #getSEG_src()
	 * @generated
	 */
	void setSEG_src(NODE value);

} // SEGMENT
