/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Simple</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see layout.LayoutPackage#getSimple()
 * @model abstract="true"
 * @generated
 */
public interface Simple extends NODE {
} // Simple
