/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Connection</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link layout.Connection#getP1 <em>P1</em>}</li>
 *   <li>{@link layout.Connection#getP2 <em>P2</em>}</li>
 * </ul>
 * </p>
 *
 * @see layout.LayoutPackage#getConnection()
 * @model
 * @generated
 */
public interface Connection extends EObject {
	/**
	 * Returns the value of the '<em><b>P1</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>P1</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>P1</em>' reference.
	 * @see #setP1(SEGMENT)
	 * @see layout.LayoutPackage#getConnection_P1()
	 * @model required="true"
	 * @generated
	 */
	SEGMENT getP1();

	/**
	 * Sets the value of the '{@link layout.Connection#getP1 <em>P1</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>P1</em>' reference.
	 * @see #getP1()
	 * @generated
	 */
	void setP1(SEGMENT value);

	/**
	 * Returns the value of the '<em><b>P2</b></em>' reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>P2</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>P2</em>' reference.
	 * @see #setP2(SEGMENT)
	 * @see layout.LayoutPackage#getConnection_P2()
	 * @model required="true"
	 * @generated
	 */
	SEGMENT getP2();

	/**
	 * Sets the value of the '{@link layout.Connection#getP2 <em>P2</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>P2</em>' reference.
	 * @see #getP2()
	 * @generated
	 */
	void setP2(SEGMENT value);

} // Connection
