/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Reversing</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see layout.LayoutPackage#getReversing()
 * @model
 * @generated
 */
public interface Reversing extends Simple {
} // Reversing
