/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Direct</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see layout.LayoutPackage#getDirect()
 * @model
 * @generated
 */
public interface Direct extends Simple {
} // Direct
