/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Point</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see layout.LayoutPackage#getPoint()
 * @model
 * @generated
 */
public interface Point extends NODE {
} // Point
