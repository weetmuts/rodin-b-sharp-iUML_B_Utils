/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout.impl;

import java.util.Collection;

import layout.ConnectionSet;
import layout.LayoutPackage;
import layout.NODE;
import layout.SEGMENT;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;
import org.eclipse.emf.ecore.impl.EObjectImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;
import org.eventb.emf.core.impl.EventBNamedCommentedElementImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>NODE</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link layout.impl.NODEImpl#getIncoming <em>Incoming</em>}</li>
 *   <li>{@link layout.impl.NODEImpl#getOutgoing <em>Outgoing</em>}</li>
 *   <li>{@link layout.impl.NODEImpl#getPotentialConnections <em>Potential Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public abstract class NODEImpl extends EventBNamedCommentedElementImpl implements NODE {
	/**
	 * The cached value of the '{@link #getIncoming() <em>Incoming</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getIncoming()
	 * @generated
	 * @ordered
	 */
	protected SEGMENT incoming;

	/**
	 * The cached value of the '{@link #getOutgoing() <em>Outgoing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getOutgoing()
	 * @generated
	 * @ordered
	 */
	protected SEGMENT outgoing;

	/**
	 * The cached value of the '{@link #getPotentialConnections() <em>Potential Connections</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getPotentialConnections()
	 * @generated
	 * @ordered
	 */
	protected EList<ConnectionSet> potentialConnections;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected NODEImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return LayoutPackage.Literals.NODE;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT getIncoming() {
		if (incoming != null && incoming.eIsProxy()) {
			InternalEObject oldIncoming = (InternalEObject)incoming;
			incoming = (SEGMENT)eResolveProxy(oldIncoming);
			if (incoming != oldIncoming) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LayoutPackage.NODE__INCOMING, oldIncoming, incoming));
			}
		}
		return incoming;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT basicGetIncoming() {
		return incoming;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetIncoming(SEGMENT newIncoming, NotificationChain msgs) {
		SEGMENT oldIncoming = incoming;
		incoming = newIncoming;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, LayoutPackage.NODE__INCOMING, oldIncoming, newIncoming);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setIncoming(SEGMENT newIncoming) {
		if (newIncoming != incoming) {
			NotificationChain msgs = null;
			if (incoming != null)
				msgs = ((InternalEObject)incoming).eInverseRemove(this, LayoutPackage.SEGMENT__SEG_DEST, SEGMENT.class, msgs);
			if (newIncoming != null)
				msgs = ((InternalEObject)newIncoming).eInverseAdd(this, LayoutPackage.SEGMENT__SEG_DEST, SEGMENT.class, msgs);
			msgs = basicSetIncoming(newIncoming, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.NODE__INCOMING, newIncoming, newIncoming));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT getOutgoing() {
		if (outgoing != null && outgoing.eIsProxy()) {
			InternalEObject oldOutgoing = (InternalEObject)outgoing;
			outgoing = (SEGMENT)eResolveProxy(oldOutgoing);
			if (outgoing != oldOutgoing) {
				if (eNotificationRequired())
					eNotify(new ENotificationImpl(this, Notification.RESOLVE, LayoutPackage.NODE__OUTGOING, oldOutgoing, outgoing));
			}
		}
		return outgoing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public SEGMENT basicGetOutgoing() {
		return outgoing;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetOutgoing(SEGMENT newOutgoing, NotificationChain msgs) {
		SEGMENT oldOutgoing = outgoing;
		outgoing = newOutgoing;
		if (eNotificationRequired()) {
			ENotificationImpl notification = new ENotificationImpl(this, Notification.SET, LayoutPackage.NODE__OUTGOING, oldOutgoing, newOutgoing);
			if (msgs == null) msgs = notification; else msgs.add(notification);
		}
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setOutgoing(SEGMENT newOutgoing) {
		if (newOutgoing != outgoing) {
			NotificationChain msgs = null;
			if (outgoing != null)
				msgs = ((InternalEObject)outgoing).eInverseRemove(this, LayoutPackage.SEGMENT__SEG_SRC, SEGMENT.class, msgs);
			if (newOutgoing != null)
				msgs = ((InternalEObject)newOutgoing).eInverseAdd(this, LayoutPackage.SEGMENT__SEG_SRC, SEGMENT.class, msgs);
			msgs = basicSetOutgoing(newOutgoing, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, LayoutPackage.NODE__OUTGOING, newOutgoing, newOutgoing));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<ConnectionSet> getPotentialConnections() {
		if (potentialConnections == null) {
			potentialConnections = new EObjectContainmentEList.Resolving<ConnectionSet>(ConnectionSet.class, this, LayoutPackage.NODE__POTENTIAL_CONNECTIONS);
		}
		return potentialConnections;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case LayoutPackage.NODE__INCOMING:
				if (incoming != null)
					msgs = ((InternalEObject)incoming).eInverseRemove(this, LayoutPackage.SEGMENT__SEG_DEST, SEGMENT.class, msgs);
				return basicSetIncoming((SEGMENT)otherEnd, msgs);
			case LayoutPackage.NODE__OUTGOING:
				if (outgoing != null)
					msgs = ((InternalEObject)outgoing).eInverseRemove(this, LayoutPackage.SEGMENT__SEG_SRC, SEGMENT.class, msgs);
				return basicSetOutgoing((SEGMENT)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case LayoutPackage.NODE__INCOMING:
				return basicSetIncoming(null, msgs);
			case LayoutPackage.NODE__OUTGOING:
				return basicSetOutgoing(null, msgs);
			case LayoutPackage.NODE__POTENTIAL_CONNECTIONS:
				return ((InternalEList<?>)getPotentialConnections()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case LayoutPackage.NODE__INCOMING:
				if (resolve) return getIncoming();
				return basicGetIncoming();
			case LayoutPackage.NODE__OUTGOING:
				if (resolve) return getOutgoing();
				return basicGetOutgoing();
			case LayoutPackage.NODE__POTENTIAL_CONNECTIONS:
				return getPotentialConnections();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case LayoutPackage.NODE__INCOMING:
				setIncoming((SEGMENT)newValue);
				return;
			case LayoutPackage.NODE__OUTGOING:
				setOutgoing((SEGMENT)newValue);
				return;
			case LayoutPackage.NODE__POTENTIAL_CONNECTIONS:
				getPotentialConnections().clear();
				getPotentialConnections().addAll((Collection<? extends ConnectionSet>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case LayoutPackage.NODE__INCOMING:
				setIncoming((SEGMENT)null);
				return;
			case LayoutPackage.NODE__OUTGOING:
				setOutgoing((SEGMENT)null);
				return;
			case LayoutPackage.NODE__POTENTIAL_CONNECTIONS:
				getPotentialConnections().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case LayoutPackage.NODE__INCOMING:
				return incoming != null;
			case LayoutPackage.NODE__OUTGOING:
				return outgoing != null;
			case LayoutPackage.NODE__POTENTIAL_CONNECTIONS:
				return potentialConnections != null && !potentialConnections.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //NODEImpl
