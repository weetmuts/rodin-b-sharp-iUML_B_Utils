/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package layout;

import org.eclipse.emf.common.util.EList;

import org.eventb.emf.core.EventBNamedCommentedElement;
import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>NODE</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link layout.NODE#getIncoming <em>Incoming</em>}</li>
 *   <li>{@link layout.NODE#getOutgoing <em>Outgoing</em>}</li>
 *   <li>{@link layout.NODE#getPotentialConnections <em>Potential Connections</em>}</li>
 * </ul>
 * </p>
 *
 * @see layout.LayoutPackage#getNODE()
 * @model abstract="true"
 * @generated
 */
public interface NODE extends EventBNamedCommentedElement {
	/**
	 * Returns the value of the '<em><b>Incoming</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link layout.SEGMENT#getSEG_dest <em>SEG dest</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Incoming</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Incoming</em>' reference.
	 * @see #setIncoming(SEGMENT)
	 * @see layout.LayoutPackage#getNODE_Incoming()
	 * @see layout.SEGMENT#getSEG_dest
	 * @model opposite="SEG_dest"
	 * @generated
	 */
	SEGMENT getIncoming();

	/**
	 * Sets the value of the '{@link layout.NODE#getIncoming <em>Incoming</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Incoming</em>' reference.
	 * @see #getIncoming()
	 * @generated
	 */
	void setIncoming(SEGMENT value);

	/**
	 * Returns the value of the '<em><b>Outgoing</b></em>' reference.
	 * It is bidirectional and its opposite is '{@link layout.SEGMENT#getSEG_src <em>SEG src</em>}'.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Outgoing</em>' reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Outgoing</em>' reference.
	 * @see #setOutgoing(SEGMENT)
	 * @see layout.LayoutPackage#getNODE_Outgoing()
	 * @see layout.SEGMENT#getSEG_src
	 * @model opposite="SEG_src"
	 * @generated
	 */
	SEGMENT getOutgoing();

	/**
	 * Sets the value of the '{@link layout.NODE#getOutgoing <em>Outgoing</em>}' reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Outgoing</em>' reference.
	 * @see #getOutgoing()
	 * @generated
	 */
	void setOutgoing(SEGMENT value);

	/**
	 * Returns the value of the '<em><b>Potential Connections</b></em>' containment reference list.
	 * The list contents are of type {@link layout.ConnectionSet}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Potential Connections</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Potential Connections</em>' containment reference list.
	 * @see layout.LayoutPackage#getNODE_PotentialConnections()
	 * @model containment="true" resolveProxies="true"
	 * @generated
	 */
	EList<ConnectionSet> getPotentialConnections();

} // NODE
