package layout.diagram.edit.helpers;

/**
 * @generated
 */
public class CrossingEditHelper extends LayoutBaseEditHelper {
}
