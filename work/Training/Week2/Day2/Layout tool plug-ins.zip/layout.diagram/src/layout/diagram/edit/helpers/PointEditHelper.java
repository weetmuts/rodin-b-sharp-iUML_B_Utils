package layout.diagram.edit.helpers;

/**
 * @generated
 */
public class PointEditHelper extends LayoutBaseEditHelper {
}
