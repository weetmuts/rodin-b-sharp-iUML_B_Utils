package layout.diagram.preferences;

import layout.diagram.part.LayoutDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.DiagramsPreferencePage;

/**
 * @generated
 */
public class DiagramGeneralPreferencePage extends DiagramsPreferencePage {

	/**
	 * @generated
	 */
	public DiagramGeneralPreferencePage() {
		setPreferenceStore(LayoutDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
