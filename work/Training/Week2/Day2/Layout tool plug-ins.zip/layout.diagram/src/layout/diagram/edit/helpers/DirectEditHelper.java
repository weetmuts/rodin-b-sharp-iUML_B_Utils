package layout.diagram.edit.helpers;

/**
 * @generated
 */
public class DirectEditHelper extends LayoutBaseEditHelper {
}
