package layout.diagram.edit.commands;

import layout.Layout;
import layout.diagram.edit.policies.LayoutBaseItemSemanticEditPolicy;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.command.CommandResult;
import org.eclipse.gmf.runtime.emf.type.core.commands.EditElementCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.ReorientRelationshipRequest;

/**
 * @generated
 */
public class SEGMENTReorientCommand extends EditElementCommand {

	/**
	 * @generated
	 */
	private final int reorientDirection;

	/**
	 * @generated
	 */
	private final EObject oldEnd;

	/**
	 * @generated
	 */
	private final EObject newEnd;

	/**
	 * @generated
	 */
	public SEGMENTReorientCommand(ReorientRelationshipRequest request) {
		super(request.getLabel(), request.getRelationship(), request);
		reorientDirection = request.getDirection();
		oldEnd = request.getOldRelationshipEnd();
		newEnd = request.getNewRelationshipEnd();
	}

	/**
	 * @generated
	 */
	public boolean canExecute() {
		if (false == getElementToEdit() instanceof layout.SEGMENT) {
			return false;
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return canReorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return canReorientTarget();
		}
		return false;
	}

	/**
	 * @generated
	 */
	protected boolean canReorientSource() {
		if (!(oldEnd instanceof Layout && newEnd instanceof Layout)) {
			return false;
		}
		layout.NODE target = getLink().getSEG_dest();
		return LayoutBaseItemSemanticEditPolicy.getLinkConstraints()
				.canExistSEGMENT_4001(getLink(), getNewSource(), target);
	}

	/**
	 * @generated
	 */
	protected boolean canReorientTarget() {
		if (!(oldEnd instanceof layout.NODE && newEnd instanceof layout.NODE)) {
			return false;
		}
		if (!(getLink().eContainer() instanceof Layout)) {
			return false;
		}
		Layout source = (Layout) getLink().eContainer();
		return LayoutBaseItemSemanticEditPolicy.getLinkConstraints()
				.canExistSEGMENT_4001(getLink(), source, getNewTarget());
	}

	/**
	 * @generated
	 */
	protected CommandResult doExecuteWithResult(IProgressMonitor monitor,
			IAdaptable info) throws ExecutionException {
		if (!canExecute()) {
			throw new ExecutionException(
					"Invalid arguments in reorient link command"); //$NON-NLS-1$
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_SOURCE) {
			return reorientSource();
		}
		if (reorientDirection == ReorientRelationshipRequest.REORIENT_TARGET) {
			return reorientTarget();
		}
		throw new IllegalStateException();
	}

	/**
	 * @generated
	 */
	protected CommandResult reorientSource() throws ExecutionException {
		getOldSource().getSegments().remove(getLink());
		getNewSource().getSegments().add(getLink());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	 * @generated
	 */
	protected CommandResult reorientTarget() throws ExecutionException {
		getLink().setSEG_dest(getNewTarget());
		return CommandResult.newOKCommandResult(getLink());
	}

	/**
	 * @generated
	 */
	protected layout.SEGMENT getLink() {
		return (layout.SEGMENT) getElementToEdit();
	}

	/**
	 * @generated
	 */
	protected Layout getOldSource() {
		return (Layout) oldEnd;
	}

	/**
	 * @generated
	 */
	protected Layout getNewSource() {
		return (Layout) newEnd;
	}

	/**
	 * @generated
	 */
	protected layout.NODE getOldTarget() {
		return (layout.NODE) oldEnd;
	}

	/**
	 * @generated
	 */
	protected layout.NODE getNewTarget() {
		return (layout.NODE) newEnd;
	}
}
