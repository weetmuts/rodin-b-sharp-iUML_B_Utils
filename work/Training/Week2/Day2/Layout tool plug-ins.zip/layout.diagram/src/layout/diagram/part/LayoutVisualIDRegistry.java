package layout.diagram.part;

import layout.Layout;
import layout.LayoutPackage;
import layout.diagram.edit.parts.CrossingEditPart;
import layout.diagram.edit.parts.CrossingNameEditPart;
import layout.diagram.edit.parts.DirectEditPart;
import layout.diagram.edit.parts.DirectNameEditPart;
import layout.diagram.edit.parts.LayoutEditPart;
import layout.diagram.edit.parts.PointEditPart;
import layout.diagram.edit.parts.PointNameEditPart;
import layout.diagram.edit.parts.ReversingEditPart;
import layout.diagram.edit.parts.ReversingNameEditPart;
import layout.diagram.edit.parts.SEGMENTEditPart;
import layout.diagram.edit.parts.SEGMENTReferenceEditPart;

import org.eclipse.core.runtime.Platform;
import org.eclipse.emf.ecore.EAnnotation;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.notation.Diagram;
import org.eclipse.gmf.runtime.notation.View;

/**
 * This registry is used to determine which type of visual object should be
 * created for the corresponding Diagram, Node, ChildNode or Link represented
 * by a domain model object.
 * 
 * @generated
 */
public class LayoutVisualIDRegistry {

	/**
	 * @generated
	 */
	private static final String DEBUG_KEY = "layout.diagram/debug/visualID"; //$NON-NLS-1$

	/**
	 * @generated
	 */
	public static int getVisualID(View view) {
		if (view instanceof Diagram) {
			if (LayoutEditPart.MODEL_ID.equals(view.getType())) {
				return LayoutEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		return layout.diagram.part.LayoutVisualIDRegistry.getVisualID(view
				.getType());
	}

	/**
	 * @generated
	 */
	public static String getModelID(View view) {
		View diagram = view.getDiagram();
		while (view != diagram) {
			EAnnotation annotation = view.getEAnnotation("Shortcut"); //$NON-NLS-1$
			if (annotation != null) {
				return (String) annotation.getDetails().get("modelID"); //$NON-NLS-1$
			}
			view = (View) view.eContainer();
		}
		return diagram != null ? diagram.getType() : null;
	}

	/**
	 * @generated
	 */
	public static int getVisualID(String type) {
		try {
			return Integer.parseInt(type);
		} catch (NumberFormatException e) {
			if (Boolean.TRUE.toString().equalsIgnoreCase(
					Platform.getDebugOption(DEBUG_KEY))) {
				LayoutDiagramEditorPlugin.getInstance().logError(
						"Unable to parse view type as a visualID number: "
								+ type);
			}
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static String getType(int visualID) {
		return Integer.toString(visualID);
	}

	/**
	 * @generated
	 */
	public static int getDiagramVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (LayoutPackage.eINSTANCE.getLayout().isSuperTypeOf(
				domainElement.eClass())
				&& isDiagram((Layout) domainElement)) {
			return LayoutEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static int getNodeVisualID(View containerView, EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		String containerModelID = layout.diagram.part.LayoutVisualIDRegistry
				.getModelID(containerView);
		if (!LayoutEditPart.MODEL_ID.equals(containerModelID)) {
			return -1;
		}
		int containerVisualID;
		if (LayoutEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = layout.diagram.part.LayoutVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = LayoutEditPart.VISUAL_ID;
			} else {
				return -1;
			}
		}
		switch (containerVisualID) {
		case LayoutEditPart.VISUAL_ID:
			if (LayoutPackage.eINSTANCE.getCrossing().isSuperTypeOf(
					domainElement.eClass())) {
				return CrossingEditPart.VISUAL_ID;
			}
			if (LayoutPackage.eINSTANCE.getDirect().isSuperTypeOf(
					domainElement.eClass())) {
				return DirectEditPart.VISUAL_ID;
			}
			if (LayoutPackage.eINSTANCE.getPoint().isSuperTypeOf(
					domainElement.eClass())) {
				return PointEditPart.VISUAL_ID;
			}
			if (LayoutPackage.eINSTANCE.getReversing().isSuperTypeOf(
					domainElement.eClass())) {
				return ReversingEditPart.VISUAL_ID;
			}
			break;
		}
		return -1;
	}

	/**
	 * @generated
	 */
	public static boolean canCreateNode(View containerView, int nodeVisualID) {
		String containerModelID = layout.diagram.part.LayoutVisualIDRegistry
				.getModelID(containerView);
		if (!LayoutEditPart.MODEL_ID.equals(containerModelID)) {
			return false;
		}
		int containerVisualID;
		if (LayoutEditPart.MODEL_ID.equals(containerModelID)) {
			containerVisualID = layout.diagram.part.LayoutVisualIDRegistry
					.getVisualID(containerView);
		} else {
			if (containerView instanceof Diagram) {
				containerVisualID = LayoutEditPart.VISUAL_ID;
			} else {
				return false;
			}
		}
		switch (containerVisualID) {
		case LayoutEditPart.VISUAL_ID:
			if (CrossingEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (DirectEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (PointEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			if (ReversingEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case CrossingEditPart.VISUAL_ID:
			if (CrossingNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case DirectEditPart.VISUAL_ID:
			if (DirectNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case PointEditPart.VISUAL_ID:
			if (PointNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case ReversingEditPart.VISUAL_ID:
			if (ReversingNameEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		case SEGMENTEditPart.VISUAL_ID:
			if (SEGMENTReferenceEditPart.VISUAL_ID == nodeVisualID) {
				return true;
			}
			break;
		}
		return false;
	}

	/**
	 * @generated
	 */
	public static int getLinkWithClassVisualID(EObject domainElement) {
		if (domainElement == null) {
			return -1;
		}
		if (LayoutPackage.eINSTANCE.getSEGMENT().isSuperTypeOf(
				domainElement.eClass())) {
			return SEGMENTEditPart.VISUAL_ID;
		}
		return -1;
	}

	/**
	 * User can change implementation of this method to handle some specific
	 * situations not covered by default logic.
	 * 
	 * @generated
	 */
	private static boolean isDiagram(Layout element) {
		return true;
	}

}
