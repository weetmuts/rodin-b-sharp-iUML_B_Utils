package layout.diagram.preferences;

import layout.diagram.part.LayoutDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.RulerGridPreferencePage;

/**
 * @generated
 */
public class DiagramRulersAndGridPreferencePage extends RulerGridPreferencePage {

	/**
	 * @generated
	 */
	public DiagramRulersAndGridPreferencePage() {
		setPreferenceStore(LayoutDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
