package layout.diagram.part;

import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import layout.Crossing;
import layout.Direct;
import layout.Layout;
import layout.LayoutPackage;
import layout.Point;
import layout.Reversing;
import layout.diagram.edit.parts.CrossingEditPart;
import layout.diagram.edit.parts.DirectEditPart;
import layout.diagram.edit.parts.LayoutEditPart;
import layout.diagram.edit.parts.PointEditPart;
import layout.diagram.edit.parts.ReversingEditPart;
import layout.diagram.edit.parts.SEGMENTEditPart;
import layout.diagram.providers.LayoutElementTypes;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.gmf.runtime.notation.View;

/**
 * @generated
 */
public class LayoutDiagramUpdater {

	/**
	 * @generated
	 */
	public static List<LayoutNodeDescriptor> getSemanticChildren(View view) {
		switch (LayoutVisualIDRegistry.getVisualID(view)) {
		case LayoutEditPart.VISUAL_ID:
			return getLayout_1000SemanticChildren(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutNodeDescriptor> getLayout_1000SemanticChildren(
			View view) {
		if (!view.isSetElement()) {
			return Collections.emptyList();
		}
		Layout modelElement = (Layout) view.getElement();
		LinkedList<LayoutNodeDescriptor> result = new LinkedList<LayoutNodeDescriptor>();
		for (Iterator<?> it = modelElement.getNodes().iterator(); it.hasNext();) {
			layout.NODE childElement = (layout.NODE) it.next();
			int visualID = LayoutVisualIDRegistry.getNodeVisualID(view,
					childElement);
			if (visualID == CrossingEditPart.VISUAL_ID) {
				result.add(new LayoutNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == DirectEditPart.VISUAL_ID) {
				result.add(new LayoutNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == PointEditPart.VISUAL_ID) {
				result.add(new LayoutNodeDescriptor(childElement, visualID));
				continue;
			}
			if (visualID == ReversingEditPart.VISUAL_ID) {
				result.add(new LayoutNodeDescriptor(childElement, visualID));
				continue;
			}
		}
		return result;
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getContainedLinks(View view) {
		switch (LayoutVisualIDRegistry.getVisualID(view)) {
		case LayoutEditPart.VISUAL_ID:
			return getLayout_1000ContainedLinks(view);
		case CrossingEditPart.VISUAL_ID:
			return getCrossing_2001ContainedLinks(view);
		case DirectEditPart.VISUAL_ID:
			return getDirect_2002ContainedLinks(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2003ContainedLinks(view);
		case ReversingEditPart.VISUAL_ID:
			return getReversing_2004ContainedLinks(view);
		case SEGMENTEditPart.VISUAL_ID:
			return getSEGMENT_4001ContainedLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getIncomingLinks(View view) {
		switch (LayoutVisualIDRegistry.getVisualID(view)) {
		case CrossingEditPart.VISUAL_ID:
			return getCrossing_2001IncomingLinks(view);
		case DirectEditPart.VISUAL_ID:
			return getDirect_2002IncomingLinks(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2003IncomingLinks(view);
		case ReversingEditPart.VISUAL_ID:
			return getReversing_2004IncomingLinks(view);
		case SEGMENTEditPart.VISUAL_ID:
			return getSEGMENT_4001IncomingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getOutgoingLinks(View view) {
		switch (LayoutVisualIDRegistry.getVisualID(view)) {
		case CrossingEditPart.VISUAL_ID:
			return getCrossing_2001OutgoingLinks(view);
		case DirectEditPart.VISUAL_ID:
			return getDirect_2002OutgoingLinks(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2003OutgoingLinks(view);
		case ReversingEditPart.VISUAL_ID:
			return getReversing_2004OutgoingLinks(view);
		case SEGMENTEditPart.VISUAL_ID:
			return getSEGMENT_4001OutgoingLinks(view);
		}
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getLayout_1000ContainedLinks(
			View view) {
		Layout modelElement = (Layout) view.getElement();
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		result.addAll(getContainedTypeModelFacetLinks_SEGMENT_4001(modelElement));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getCrossing_2001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getDirect_2002ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getPoint_2003ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getReversing_2004ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getSEGMENT_4001ContainedLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getCrossing_2001IncomingLinks(
			View view) {
		Crossing modelElement = (Crossing) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SEGMENT_4001(modelElement,
				crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getDirect_2002IncomingLinks(
			View view) {
		Direct modelElement = (Direct) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SEGMENT_4001(modelElement,
				crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getPoint_2003IncomingLinks(
			View view) {
		Point modelElement = (Point) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SEGMENT_4001(modelElement,
				crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getReversing_2004IncomingLinks(
			View view) {
		Reversing modelElement = (Reversing) view.getElement();
		Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences = EcoreUtil.CrossReferencer
				.find(view.eResource().getResourceSet().getResources());
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		result.addAll(getIncomingTypeModelFacetLinks_SEGMENT_4001(modelElement,
				crossReferences));
		return result;
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getSEGMENT_4001IncomingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getCrossing_2001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getDirect_2002OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getPoint_2003OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getReversing_2004OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	public static List<LayoutLinkDescriptor> getSEGMENT_4001OutgoingLinks(
			View view) {
		return Collections.emptyList();
	}

	/**
	 * @generated
	 */
	private static Collection<LayoutLinkDescriptor> getContainedTypeModelFacetLinks_SEGMENT_4001(
			Layout container) {
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		for (Iterator<?> links = container.getSegments().iterator(); links
				.hasNext();) {
			EObject linkObject = (EObject) links.next();
			if (false == linkObject instanceof layout.SEGMENT) {
				continue;
			}
			layout.SEGMENT link = (layout.SEGMENT) linkObject;
			if (SEGMENTEditPart.VISUAL_ID != LayoutVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			layout.NODE dst = link.getSEG_dest();
			result.add(new LayoutLinkDescriptor(container, dst, link,
					LayoutElementTypes.SEGMENT_4001, SEGMENTEditPart.VISUAL_ID));
		}
		return result;
	}

	/**
	 * @generated
	 */
	private static Collection<LayoutLinkDescriptor> getIncomingTypeModelFacetLinks_SEGMENT_4001(
			layout.NODE target,
			Map<EObject, Collection<EStructuralFeature.Setting>> crossReferences) {
		LinkedList<LayoutLinkDescriptor> result = new LinkedList<LayoutLinkDescriptor>();
		Collection<EStructuralFeature.Setting> settings = crossReferences
				.get(target);
		for (EStructuralFeature.Setting setting : settings) {
			if (setting.getEStructuralFeature() != LayoutPackage.eINSTANCE
					.getSEGMENT_SEG_dest()
					|| false == setting.getEObject() instanceof layout.SEGMENT) {
				continue;
			}
			layout.SEGMENT link = (layout.SEGMENT) setting.getEObject();
			if (SEGMENTEditPart.VISUAL_ID != LayoutVisualIDRegistry
					.getLinkWithClassVisualID(link)) {
				continue;
			}
			if (false == link.eContainer() instanceof Layout) {
				continue;
			}
			Layout container = (Layout) link.eContainer();
			result.add(new LayoutLinkDescriptor(container, target, link,
					LayoutElementTypes.SEGMENT_4001, SEGMENTEditPart.VISUAL_ID));

		}
		return result;
	}

}
