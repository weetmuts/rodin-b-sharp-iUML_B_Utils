package layout.diagram.preferences;

import layout.diagram.part.LayoutDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.PrintingPreferencePage;

/**
 * @generated
 */
public class DiagramPrintingPreferencePage extends PrintingPreferencePage {

	/**
	 * @generated
	 */
	public DiagramPrintingPreferencePage() {
		setPreferenceStore(LayoutDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
