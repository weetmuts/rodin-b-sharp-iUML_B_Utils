package layout.diagram.preferences;

import layout.diagram.part.LayoutDiagramEditorPlugin;

import org.eclipse.gmf.runtime.diagram.ui.preferences.AppearancePreferencePage;

/**
 * @generated
 */
public class DiagramAppearancePreferencePage extends AppearancePreferencePage {

	/**
	 * @generated
	 */
	public DiagramAppearancePreferencePage() {
		setPreferenceStore(LayoutDiagramEditorPlugin.getInstance()
				.getPreferenceStore());
	}
}
