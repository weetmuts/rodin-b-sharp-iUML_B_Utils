package layout.diagram.edit.helpers;

/**
 * @generated
 */
public class SEGMENTEditHelper extends LayoutBaseEditHelper {
}
