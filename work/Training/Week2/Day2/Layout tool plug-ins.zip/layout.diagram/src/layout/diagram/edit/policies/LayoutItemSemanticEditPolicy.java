package layout.diagram.edit.policies;

import layout.diagram.edit.commands.CrossingCreateCommand;
import layout.diagram.edit.commands.DirectCreateCommand;
import layout.diagram.edit.commands.PointCreateCommand;
import layout.diagram.edit.commands.ReversingCreateCommand;
import layout.diagram.providers.LayoutElementTypes;

import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.gef.commands.Command;
import org.eclipse.gmf.runtime.diagram.ui.editparts.IGraphicalEditPart;
import org.eclipse.gmf.runtime.emf.commands.core.commands.DuplicateEObjectsCommand;
import org.eclipse.gmf.runtime.emf.type.core.requests.CreateElementRequest;
import org.eclipse.gmf.runtime.emf.type.core.requests.DuplicateElementsRequest;

/**
 * @generated
 */
public class LayoutItemSemanticEditPolicy extends
		LayoutBaseItemSemanticEditPolicy {

	/**
	 * @generated
	 */
	public LayoutItemSemanticEditPolicy() {
		super(LayoutElementTypes.Layout_1000);
	}

	/**
	 * @generated
	 */
	protected Command getCreateCommand(CreateElementRequest req) {
		if (LayoutElementTypes.Crossing_2001 == req.getElementType()) {
			return getGEFWrapper(new CrossingCreateCommand(req));
		}
		if (LayoutElementTypes.Direct_2002 == req.getElementType()) {
			return getGEFWrapper(new DirectCreateCommand(req));
		}
		if (LayoutElementTypes.Point_2003 == req.getElementType()) {
			return getGEFWrapper(new PointCreateCommand(req));
		}
		if (LayoutElementTypes.Reversing_2004 == req.getElementType()) {
			return getGEFWrapper(new ReversingCreateCommand(req));
		}
		return super.getCreateCommand(req);
	}

	/**
	 * @generated
	 */
	protected Command getDuplicateCommand(DuplicateElementsRequest req) {
		TransactionalEditingDomain editingDomain = ((IGraphicalEditPart) getHost())
				.getEditingDomain();
		return getGEFWrapper(new DuplicateAnythingCommand(editingDomain, req));
	}

	/**
	 * @generated
	 */
	private static class DuplicateAnythingCommand extends
			DuplicateEObjectsCommand {

		/**
		 * @generated
		 */
		public DuplicateAnythingCommand(
				TransactionalEditingDomain editingDomain,
				DuplicateElementsRequest req) {
			super(editingDomain, req.getLabel(), req
					.getElementsToBeDuplicated(), req
					.getAllDuplicatedElementsMap());
		}

	}

}
