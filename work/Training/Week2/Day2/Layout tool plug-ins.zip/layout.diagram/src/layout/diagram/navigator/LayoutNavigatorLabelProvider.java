package layout.diagram.navigator;

import layout.Layout;
import layout.diagram.edit.parts.CrossingEditPart;
import layout.diagram.edit.parts.CrossingNameEditPart;
import layout.diagram.edit.parts.DirectEditPart;
import layout.diagram.edit.parts.DirectNameEditPart;
import layout.diagram.edit.parts.LayoutEditPart;
import layout.diagram.edit.parts.PointEditPart;
import layout.diagram.edit.parts.PointNameEditPart;
import layout.diagram.edit.parts.ReversingEditPart;
import layout.diagram.edit.parts.ReversingNameEditPart;
import layout.diagram.edit.parts.SEGMENTEditPart;
import layout.diagram.edit.parts.SEGMENTReferenceEditPart;
import layout.diagram.part.LayoutDiagramEditorPlugin;
import layout.diagram.part.LayoutVisualIDRegistry;
import layout.diagram.providers.LayoutElementTypes;
import layout.diagram.providers.LayoutParserProvider;

import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserOptions;
import org.eclipse.gmf.runtime.emf.core.util.EObjectAdapter;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.notation.View;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.jface.viewers.ITreePathLabelProvider;
import org.eclipse.jface.viewers.LabelProvider;
import org.eclipse.jface.viewers.TreePath;
import org.eclipse.jface.viewers.ViewerLabel;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMemento;
import org.eclipse.ui.navigator.ICommonContentExtensionSite;
import org.eclipse.ui.navigator.ICommonLabelProvider;

/**
 * @generated
 */
public class LayoutNavigatorLabelProvider extends LabelProvider implements
		ICommonLabelProvider, ITreePathLabelProvider {

	/**
	 * @generated
	 */
	static {
		LayoutDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?UnknownElement", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
		LayoutDiagramEditorPlugin
				.getInstance()
				.getImageRegistry()
				.put("Navigator?ImageNotFound", ImageDescriptor.getMissingImageDescriptor()); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	public void updateLabel(ViewerLabel label, TreePath elementPath) {
		Object element = elementPath.getLastSegment();
		if (element instanceof LayoutNavigatorItem
				&& !isOwnView(((LayoutNavigatorItem) element).getView())) {
			return;
		}
		label.setText(getText(element));
		label.setImage(getImage(element));
	}

	/**
	 * @generated
	 */
	public Image getImage(Object element) {
		if (element instanceof LayoutNavigatorGroup) {
			LayoutNavigatorGroup group = (LayoutNavigatorGroup) element;
			return LayoutDiagramEditorPlugin.getInstance().getBundledImage(
					group.getIcon());
		}

		if (element instanceof LayoutNavigatorItem) {
			LayoutNavigatorItem navigatorItem = (LayoutNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return super.getImage(element);
			}
			return getImage(navigatorItem.getView());
		}

		return super.getImage(element);
	}

	/**
	 * @generated
	 */
	public Image getImage(View view) {
		switch (LayoutVisualIDRegistry.getVisualID(view)) {
		case CrossingEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://thales/models/eventb/layout?Crossing", LayoutElementTypes.Crossing_2001); //$NON-NLS-1$
		case ReversingEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://thales/models/eventb/layout?Reversing", LayoutElementTypes.Reversing_2004); //$NON-NLS-1$
		case SEGMENTEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Link?http://thales/models/eventb/layout?SEGMENT", LayoutElementTypes.SEGMENT_4001); //$NON-NLS-1$
		case DirectEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://thales/models/eventb/layout?Direct", LayoutElementTypes.Direct_2002); //$NON-NLS-1$
		case LayoutEditPart.VISUAL_ID:
			return getImage(
					"Navigator?Diagram?http://thales/models/eventb/layout?Layout", LayoutElementTypes.Layout_1000); //$NON-NLS-1$
		case PointEditPart.VISUAL_ID:
			return getImage(
					"Navigator?TopLevelNode?http://thales/models/eventb/layout?Point", LayoutElementTypes.Point_2003); //$NON-NLS-1$
		}
		return getImage("Navigator?UnknownElement", null); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Image getImage(String key, IElementType elementType) {
		ImageRegistry imageRegistry = LayoutDiagramEditorPlugin.getInstance()
				.getImageRegistry();
		Image image = imageRegistry.get(key);
		if (image == null && elementType != null
				&& LayoutElementTypes.isKnownElementType(elementType)) {
			image = LayoutElementTypes.getImage(elementType);
			imageRegistry.put(key, image);
		}

		if (image == null) {
			image = imageRegistry.get("Navigator?ImageNotFound"); //$NON-NLS-1$
			imageRegistry.put(key, image);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public String getText(Object element) {
		if (element instanceof LayoutNavigatorGroup) {
			LayoutNavigatorGroup group = (LayoutNavigatorGroup) element;
			return group.getGroupName();
		}

		if (element instanceof LayoutNavigatorItem) {
			LayoutNavigatorItem navigatorItem = (LayoutNavigatorItem) element;
			if (!isOwnView(navigatorItem.getView())) {
				return null;
			}
			return getText(navigatorItem.getView());
		}

		return super.getText(element);
	}

	/**
	 * @generated
	 */
	public String getText(View view) {
		if (view.getElement() != null && view.getElement().eIsProxy()) {
			return getUnresolvedDomainElementProxyText(view);
		}
		switch (LayoutVisualIDRegistry.getVisualID(view)) {
		case CrossingEditPart.VISUAL_ID:
			return getCrossing_2001Text(view);
		case ReversingEditPart.VISUAL_ID:
			return getReversing_2004Text(view);
		case SEGMENTEditPart.VISUAL_ID:
			return getSEGMENT_4001Text(view);
		case DirectEditPart.VISUAL_ID:
			return getDirect_2002Text(view);
		case LayoutEditPart.VISUAL_ID:
			return getLayout_1000Text(view);
		case PointEditPart.VISUAL_ID:
			return getPoint_2003Text(view);
		}
		return getUnknownElementText(view);
	}

	/**
	 * @generated
	 */
	private String getCrossing_2001Text(View view) {
		IParser parser = LayoutParserProvider.getParser(
				LayoutElementTypes.Crossing_2001,
				view.getElement() != null ? view.getElement() : view,
				LayoutVisualIDRegistry.getType(CrossingNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			LayoutDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getReversing_2004Text(View view) {
		IParser parser = LayoutParserProvider
				.getParser(LayoutElementTypes.Reversing_2004,
						view.getElement() != null ? view.getElement() : view,
						LayoutVisualIDRegistry
								.getType(ReversingNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			LayoutDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5004); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getSEGMENT_4001Text(View view) {
		IParser parser = LayoutParserProvider.getParser(
				LayoutElementTypes.SEGMENT_4001,
				view.getElement() != null ? view.getElement() : view,
				LayoutVisualIDRegistry
						.getType(SEGMENTReferenceEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			LayoutDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 6001); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getDirect_2002Text(View view) {
		IParser parser = LayoutParserProvider.getParser(
				LayoutElementTypes.Direct_2002,
				view.getElement() != null ? view.getElement() : view,
				LayoutVisualIDRegistry.getType(DirectNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			LayoutDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5002); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getLayout_1000Text(View view) {
		Layout domainModelElement = (Layout) view.getElement();
		if (domainModelElement != null) {
			return domainModelElement.getName();
		} else {
			LayoutDiagramEditorPlugin.getInstance().logError(
					"No domain element for view with visualID = " + 1000); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getPoint_2003Text(View view) {
		IParser parser = LayoutParserProvider.getParser(
				LayoutElementTypes.Point_2003,
				view.getElement() != null ? view.getElement() : view,
				LayoutVisualIDRegistry.getType(PointNameEditPart.VISUAL_ID));
		if (parser != null) {
			return parser.getPrintString(new EObjectAdapter(
					view.getElement() != null ? view.getElement() : view),
					ParserOptions.NONE.intValue());
		} else {
			LayoutDiagramEditorPlugin.getInstance().logError(
					"Parser was not found for label " + 5003); //$NON-NLS-1$
			return ""; //$NON-NLS-1$
		}
	}

	/**
	 * @generated
	 */
	private String getUnknownElementText(View view) {
		return "<UnknownElement Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	private String getUnresolvedDomainElementProxyText(View view) {
		return "<Unresolved domain element Visual_ID = " + view.getType() + ">"; //$NON-NLS-1$  //$NON-NLS-2$
	}

	/**
	 * @generated
	 */
	public void init(ICommonContentExtensionSite aConfig) {
	}

	/**
	 * @generated
	 */
	public void restoreState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public void saveState(IMemento aMemento) {
	}

	/**
	 * @generated
	 */
	public String getDescription(Object anElement) {
		return null;
	}

	/**
	 * @generated
	 */
	private boolean isOwnView(View view) {
		return LayoutEditPart.MODEL_ID.equals(LayoutVisualIDRegistry
				.getModelID(view));
	}

}
