package layout.diagram.edit.helpers;

/**
 * @generated
 */
public class LayoutEditHelper extends LayoutBaseEditHelper {
}
