package layout.diagram.part;

import org.eclipse.osgi.util.NLS;

/**
 * @generated
 */
public class Messages extends NLS {

	/**
	 * @generated
	 */
	static {
		NLS.initializeMessages("messages", Messages.class); //$NON-NLS-1$
	}

	/**
	 * @generated
	 */
	private Messages() {
	}

	/**
	 * @generated
	 */
	public static String LayoutCreationWizardTitle;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizard_DiagramModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizard_DiagramModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizard_DomainModelFilePageTitle;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizard_DomainModelFilePageDescription;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizardOpenEditorError;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizardCreationError;

	/**
	 * @generated
	 */
	public static String LayoutCreationWizardPageExtensionError;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditorUtil_OpenModelResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditorUtil_OpenModelResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditorUtil_CreateDiagramProgressTask;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditorUtil_CreateDiagramCommandLabel;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_isModifiable;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_handleElementContentChanged;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_IncorrectInputError;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_NoDiagramInResourceError;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_DiagramLoadingError;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_UnsynchronizedFileSaveError;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_SaveDiagramTask;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_SaveNextResourceTask;

	/**
	 * @generated
	 */
	public static String LayoutDocumentProvider_SaveAsOperation;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_ResourceErrorDialogMessage;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_WizardTitle;

	/**
	 * @generated
	 */
	public static String InitDiagramFile_OpenModelFileDialogTitle;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_CreationPageName;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_CreationPageTitle;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_CreationPageDescription;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_RootSelectionPageName;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_RootSelectionPageTitle;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_RootSelectionPageDescription;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_RootSelectionPageSelectionTitle;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_RootSelectionPageNoSelectionMessage;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_RootSelectionPageInvalidSelectionMessage;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_InitDiagramCommand;

	/**
	 * @generated
	 */
	public static String LayoutNewDiagramFileWizard_IncorrectRootError;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditor_SavingDeletedFile;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditor_SaveAsErrorTitle;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditor_SaveAsErrorMessage;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditor_SaveErrorTitle;

	/**
	 * @generated
	 */
	public static String LayoutDiagramEditor_SaveErrorMessage;

	/**
	 * @generated
	 */
	public static String LayoutElementChooserDialog_SelectModelElementTitle;

	/**
	 * @generated
	 */
	public static String ModelElementSelectionPageMessage;

	/**
	 * @generated
	 */
	public static String ValidateActionMessage;

	/**
	 * @generated
	 */
	public static String Layout1Group_title;

	/**
	 * @generated
	 */
	public static String SEGMENT1CreationTool_title;

	/**
	 * @generated
	 */
	public static String SEGMENT1CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Crossing2CreationTool_title;

	/**
	 * @generated
	 */
	public static String Crossing2CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Point3CreationTool_title;

	/**
	 * @generated
	 */
	public static String Point3CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Reversing4CreationTool_title;

	/**
	 * @generated
	 */
	public static String Reversing4CreationTool_desc;

	/**
	 * @generated
	 */
	public static String Direct5CreationTool_title;

	/**
	 * @generated
	 */
	public static String Direct5CreationTool_desc;

	/**
	 * @generated
	 */
	public static String CommandName_OpenDiagram;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Crossing_2001_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Reversing_2004_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_SEGMENT_4001_target;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Direct_2002_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Layout_1000_links;

	/**
	 * @generated
	 */
	public static String NavigatorGroupName_Point_2003_incominglinks;

	/**
	 * @generated
	 */
	public static String NavigatorActionProvider_OpenDiagramActionName;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnexpectedValueType;

	/**
	 * @generated
	 */
	public static String AbstractParser_WrongStringConversion;

	/**
	 * @generated
	 */
	public static String AbstractParser_UnknownLiteral;

	/**
	 * @generated
	 */
	public static String MessageFormatParser_InvalidInputError;

	/**
	 * @generated
	 */
	public static String LayoutModelingAssistantProviderTitle;

	/**
	 * @generated
	 */
	public static String LayoutModelingAssistantProviderMessage;

	//TODO: put accessor fields manually	
}
