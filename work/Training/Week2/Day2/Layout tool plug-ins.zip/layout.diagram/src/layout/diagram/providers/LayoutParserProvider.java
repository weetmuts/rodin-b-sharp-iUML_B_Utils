package layout.diagram.providers;

import layout.diagram.edit.parts.CrossingNameEditPart;
import layout.diagram.edit.parts.DirectNameEditPart;
import layout.diagram.edit.parts.PointNameEditPart;
import layout.diagram.edit.parts.ReversingNameEditPart;
import layout.diagram.edit.parts.SEGMENTReferenceEditPart;
import layout.diagram.parsers.MessageFormatParser;
import layout.diagram.part.LayoutVisualIDRegistry;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.gmf.runtime.common.core.service.AbstractProvider;
import org.eclipse.gmf.runtime.common.core.service.IOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.GetParserOperation;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParser;
import org.eclipse.gmf.runtime.common.ui.services.parser.IParserProvider;
import org.eclipse.gmf.runtime.common.ui.services.parser.ParserService;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.gmf.runtime.emf.ui.services.parser.ParserHintAdapter;
import org.eclipse.gmf.runtime.notation.View;
import org.eventb.emf.core.CorePackage;

/**
 * @generated
 */
public class LayoutParserProvider extends AbstractProvider implements
		IParserProvider {

	/**
	 * @generated
	 */
	private IParser crossingName_5001Parser;

	/**
	 * @generated
	 */
	private IParser getCrossingName_5001Parser() {
		if (crossingName_5001Parser == null) {
			EAttribute[] features = new EAttribute[] { CorePackage.eINSTANCE
					.getEventBNamed_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			crossingName_5001Parser = parser;
		}
		return crossingName_5001Parser;
	}

	/**
	 * @generated
	 */
	private IParser directName_5002Parser;

	/**
	 * @generated
	 */
	private IParser getDirectName_5002Parser() {
		if (directName_5002Parser == null) {
			EAttribute[] features = new EAttribute[] { CorePackage.eINSTANCE
					.getEventBNamed_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			directName_5002Parser = parser;
		}
		return directName_5002Parser;
	}

	/**
	 * @generated
	 */
	private IParser pointName_5003Parser;

	/**
	 * @generated
	 */
	private IParser getPointName_5003Parser() {
		if (pointName_5003Parser == null) {
			EAttribute[] features = new EAttribute[] { CorePackage.eINSTANCE
					.getEventBNamed_Name() };
			MessageFormatParser parser = new MessageFormatParser(features);
			pointName_5003Parser = parser;
		}
		return pointName_5003Parser;
	}

	/**
	 * @generated
	 */
	private IParser reversingName_5004Parser;

	/**
	 * @generated
	 */
	private IParser getReversingName_5004Parser() {
		if (reversingName_5004Parser == null) {
			EAttribute[] features = new EAttribute[] { CorePackage.eINSTANCE
					.getEventBNamed_Name() };
			EAttribute[] editableFeatures = new EAttribute[] { CorePackage.eINSTANCE
					.getEventBNamed_Name() };
			MessageFormatParser parser = new MessageFormatParser(features,
					editableFeatures);
			reversingName_5004Parser = parser;
		}
		return reversingName_5004Parser;
	}

	/**
	 * @generated
	 */
	private IParser sEGMENTReference_6001Parser;

	/**
	 * @generated
	 */
	private IParser getSEGMENTReference_6001Parser() {
		if (sEGMENTReference_6001Parser == null) {
			EAttribute[] features = new EAttribute[] { CorePackage.eINSTANCE
					.getEventBElement_Reference() };
			MessageFormatParser parser = new MessageFormatParser(features);
			sEGMENTReference_6001Parser = parser;
		}
		return sEGMENTReference_6001Parser;
	}

	/**
	 * @generated
	 */
	protected IParser getParser(int visualID) {
		switch (visualID) {
		case CrossingNameEditPart.VISUAL_ID:
			return getCrossingName_5001Parser();
		case DirectNameEditPart.VISUAL_ID:
			return getDirectName_5002Parser();
		case PointNameEditPart.VISUAL_ID:
			return getPointName_5003Parser();
		case ReversingNameEditPart.VISUAL_ID:
			return getReversingName_5004Parser();
		case SEGMENTReferenceEditPart.VISUAL_ID:
			return getSEGMENTReference_6001Parser();
		}
		return null;
	}

	/**
	 * Utility method that consults ParserService
	 * @generated
	 */
	public static IParser getParser(IElementType type, EObject object,
			String parserHint) {
		return ParserService.getInstance().getParser(
				new HintAdapter(type, object, parserHint));
	}

	/**
	 * @generated
	 */
	public IParser getParser(IAdaptable hint) {
		String vid = (String) hint.getAdapter(String.class);
		if (vid != null) {
			return getParser(LayoutVisualIDRegistry.getVisualID(vid));
		}
		View view = (View) hint.getAdapter(View.class);
		if (view != null) {
			return getParser(LayoutVisualIDRegistry.getVisualID(view));
		}
		return null;
	}

	/**
	 * @generated
	 */
	public boolean provides(IOperation operation) {
		if (operation instanceof GetParserOperation) {
			IAdaptable hint = ((GetParserOperation) operation).getHint();
			if (LayoutElementTypes.getElement(hint) == null) {
				return false;
			}
			return getParser(hint) != null;
		}
		return false;
	}

	/**
	 * @generated
	 */
	private static class HintAdapter extends ParserHintAdapter {

		/**
		 * @generated
		 */
		private final IElementType elementType;

		/**
		 * @generated
		 */
		public HintAdapter(IElementType type, EObject object, String parserHint) {
			super(object, parserHint);
			assert type != null;
			elementType = type;
		}

		/**
		 * @generated
		 */
		public Object getAdapter(Class adapter) {
			if (IElementType.class.equals(adapter)) {
				return elementType;
			}
			return super.getAdapter(adapter);
		}
	}

}
