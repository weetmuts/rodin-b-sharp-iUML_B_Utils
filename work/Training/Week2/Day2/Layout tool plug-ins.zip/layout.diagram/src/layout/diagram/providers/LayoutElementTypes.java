package layout.diagram.providers;

import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.Set;

import layout.LayoutPackage;
import layout.diagram.edit.parts.CrossingEditPart;
import layout.diagram.edit.parts.DirectEditPart;
import layout.diagram.edit.parts.LayoutEditPart;
import layout.diagram.edit.parts.PointEditPart;
import layout.diagram.edit.parts.ReversingEditPart;
import layout.diagram.edit.parts.SEGMENTEditPart;
import layout.diagram.part.LayoutDiagramEditorPlugin;

import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EClassifier;
import org.eclipse.emf.ecore.ENamedElement;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.gmf.runtime.emf.type.core.ElementTypeRegistry;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;
import org.eclipse.jface.resource.ImageDescriptor;
import org.eclipse.jface.resource.ImageRegistry;
import org.eclipse.swt.graphics.Image;

/**
 * @generated
 */
public class LayoutElementTypes {

	/**
	 * @generated
	 */
	private LayoutElementTypes() {
	}

	/**
	 * @generated
	 */
	private static Map<IElementType, ENamedElement> elements;

	/**
	 * @generated
	 */
	private static ImageRegistry imageRegistry;

	/**
	 * @generated
	 */
	private static Set<IElementType> KNOWN_ELEMENT_TYPES;

	/**
	 * @generated
	 */
	public static final IElementType Layout_1000 = getElementType("layout.diagram.Layout_1000"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Crossing_2001 = getElementType("layout.diagram.Crossing_2001"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Direct_2002 = getElementType("layout.diagram.Direct_2002"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Point_2003 = getElementType("layout.diagram.Point_2003"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType Reversing_2004 = getElementType("layout.diagram.Reversing_2004"); //$NON-NLS-1$
	/**
	 * @generated
	 */
	public static final IElementType SEGMENT_4001 = getElementType("layout.diagram.SEGMENT_4001"); //$NON-NLS-1$

	/**
	 * @generated
	 */
	private static ImageRegistry getImageRegistry() {
		if (imageRegistry == null) {
			imageRegistry = new ImageRegistry();
		}
		return imageRegistry;
	}

	/**
	 * @generated
	 */
	private static String getImageRegistryKey(ENamedElement element) {
		return element.getName();
	}

	/**
	 * @generated
	 */
	private static ImageDescriptor getProvidedImageDescriptor(
			ENamedElement element) {
		if (element instanceof EStructuralFeature) {
			EStructuralFeature feature = ((EStructuralFeature) element);
			EClass eContainingClass = feature.getEContainingClass();
			EClassifier eType = feature.getEType();
			if (eContainingClass != null && !eContainingClass.isAbstract()) {
				element = eContainingClass;
			} else if (eType instanceof EClass
					&& !((EClass) eType).isAbstract()) {
				element = eType;
			}
		}
		if (element instanceof EClass) {
			EClass eClass = (EClass) element;
			if (!eClass.isAbstract()) {
				return LayoutDiagramEditorPlugin.getInstance()
						.getItemImageDescriptor(
								eClass.getEPackage().getEFactoryInstance()
										.create(eClass));
			}
		}
		// TODO : support structural features
		return null;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(ENamedElement element) {
		String key = getImageRegistryKey(element);
		ImageDescriptor imageDescriptor = getImageRegistry().getDescriptor(key);
		if (imageDescriptor == null) {
			imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
		}
		return imageDescriptor;
	}

	/**
	 * @generated
	 */
	public static Image getImage(ENamedElement element) {
		String key = getImageRegistryKey(element);
		Image image = getImageRegistry().get(key);
		if (image == null) {
			ImageDescriptor imageDescriptor = getProvidedImageDescriptor(element);
			if (imageDescriptor == null) {
				imageDescriptor = ImageDescriptor.getMissingImageDescriptor();
			}
			getImageRegistry().put(key, imageDescriptor);
			image = getImageRegistry().get(key);
		}
		return image;
	}

	/**
	 * @generated
	 */
	public static ImageDescriptor getImageDescriptor(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImageDescriptor(element);
	}

	/**
	 * @generated
	 */
	public static Image getImage(IAdaptable hint) {
		ENamedElement element = getElement(hint);
		if (element == null) {
			return null;
		}
		return getImage(element);
	}

	/**
	 * Returns 'type' of the ecore object associated with the hint.
	 * 
	 * @generated
	 */
	public static ENamedElement getElement(IAdaptable hint) {
		Object type = hint.getAdapter(IElementType.class);
		if (elements == null) {
			elements = new IdentityHashMap<IElementType, ENamedElement>();

			elements.put(Layout_1000, LayoutPackage.eINSTANCE.getLayout());

			elements.put(Crossing_2001, LayoutPackage.eINSTANCE.getCrossing());

			elements.put(Direct_2002, LayoutPackage.eINSTANCE.getDirect());

			elements.put(Point_2003, LayoutPackage.eINSTANCE.getPoint());

			elements.put(Reversing_2004, LayoutPackage.eINSTANCE.getReversing());

			elements.put(SEGMENT_4001, LayoutPackage.eINSTANCE.getSEGMENT());
		}
		return (ENamedElement) elements.get(type);
	}

	/**
	 * @generated
	 */
	private static IElementType getElementType(String id) {
		return ElementTypeRegistry.getInstance().getType(id);
	}

	/**
	 * @generated
	 */
	public static boolean isKnownElementType(IElementType elementType) {
		if (KNOWN_ELEMENT_TYPES == null) {
			KNOWN_ELEMENT_TYPES = new HashSet<IElementType>();
			KNOWN_ELEMENT_TYPES.add(Layout_1000);
			KNOWN_ELEMENT_TYPES.add(Crossing_2001);
			KNOWN_ELEMENT_TYPES.add(Direct_2002);
			KNOWN_ELEMENT_TYPES.add(Point_2003);
			KNOWN_ELEMENT_TYPES.add(Reversing_2004);
			KNOWN_ELEMENT_TYPES.add(SEGMENT_4001);
		}
		return KNOWN_ELEMENT_TYPES.contains(elementType);
	}

	/**
	 * @generated
	 */
	public static IElementType getElementType(int visualID) {
		switch (visualID) {
		case LayoutEditPart.VISUAL_ID:
			return Layout_1000;
		case CrossingEditPart.VISUAL_ID:
			return Crossing_2001;
		case DirectEditPart.VISUAL_ID:
			return Direct_2002;
		case PointEditPart.VISUAL_ID:
			return Point_2003;
		case ReversingEditPart.VISUAL_ID:
			return Reversing_2004;
		case SEGMENTEditPart.VISUAL_ID:
			return SEGMENT_4001;
		}
		return null;
	}

}
