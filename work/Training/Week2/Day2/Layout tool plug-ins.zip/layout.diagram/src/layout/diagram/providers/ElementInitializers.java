package layout.diagram.providers;

import layout.diagram.part.LayoutDiagramEditorPlugin;

/**
 * @generated
 */
public class ElementInitializers {

	protected ElementInitializers() {
		// use #getInstance to access cached instance
	}

	/**
	 * @generated
	 */
	public static ElementInitializers getInstance() {
		ElementInitializers cached = LayoutDiagramEditorPlugin.getInstance()
				.getElementInitializers();
		if (cached == null) {
			LayoutDiagramEditorPlugin.getInstance().setElementInitializers(
					cached = new ElementInitializers());
		}
		return cached;
	}
}
