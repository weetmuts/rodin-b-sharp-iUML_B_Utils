package layout.diagram.navigator;

import layout.diagram.part.LayoutVisualIDRegistry;

import org.eclipse.jface.viewers.ViewerSorter;

/**
 * @generated
 */
public class LayoutNavigatorSorter extends ViewerSorter {

	/**
	 * @generated
	 */
	private static final int GROUP_CATEGORY = 4003;

	/**
	 * @generated
	 */
	public int category(Object element) {
		if (element instanceof LayoutNavigatorItem) {
			LayoutNavigatorItem item = (LayoutNavigatorItem) element;
			return LayoutVisualIDRegistry.getVisualID(item.getView());
		}
		return GROUP_CATEGORY;
	}

}
