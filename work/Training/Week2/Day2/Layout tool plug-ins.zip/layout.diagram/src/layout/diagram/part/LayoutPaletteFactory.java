package layout.diagram.part;

import java.util.Collections;
import java.util.List;

import layout.diagram.providers.LayoutElementTypes;

import org.eclipse.gef.Tool;
import org.eclipse.gef.palette.PaletteContainer;
import org.eclipse.gef.palette.PaletteGroup;
import org.eclipse.gef.palette.PaletteRoot;
import org.eclipse.gef.palette.ToolEntry;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeConnectionTool;
import org.eclipse.gmf.runtime.diagram.ui.tools.UnspecifiedTypeCreationTool;
import org.eclipse.gmf.runtime.emf.type.core.IElementType;

/**
 * @generated
 */
public class LayoutPaletteFactory {

	/**
	 * @generated
	 */
	public void fillPalette(PaletteRoot paletteRoot) {
		paletteRoot.add(createLayout1Group());
	}

	/**
	 * Creates "layout" palette tool group
	 * @generated
	 */
	private PaletteContainer createLayout1Group() {
		PaletteGroup paletteContainer = new PaletteGroup(
				Messages.Layout1Group_title);
		paletteContainer.setId("createLayout1Group"); //$NON-NLS-1$
		paletteContainer.add(createSEGMENT1CreationTool());
		paletteContainer.add(createCrossing2CreationTool());
		paletteContainer.add(createPoint3CreationTool());
		paletteContainer.add(createReversing4CreationTool());
		paletteContainer.add(createDirect5CreationTool());
		return paletteContainer;
	}

	/**
	 * @generated
	 */
	private ToolEntry createSEGMENT1CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.SEGMENT1CreationTool_title,
				Messages.SEGMENT1CreationTool_desc,
				Collections.singletonList(LayoutElementTypes.Crossing_2001));
		entry.setId("createSEGMENT1CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(LayoutElementTypes
				.getImageDescriptor(LayoutElementTypes.Crossing_2001));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createCrossing2CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Crossing2CreationTool_title,
				Messages.Crossing2CreationTool_desc,
				Collections.singletonList(LayoutElementTypes.Direct_2002));
		entry.setId("createCrossing2CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(LayoutElementTypes
				.getImageDescriptor(LayoutElementTypes.Direct_2002));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createPoint3CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Point3CreationTool_title,
				Messages.Point3CreationTool_desc,
				Collections.singletonList(LayoutElementTypes.Point_2003));
		entry.setId("createPoint3CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(LayoutElementTypes
				.getImageDescriptor(LayoutElementTypes.Point_2003));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createReversing4CreationTool() {
		ToolEntry entry = new ToolEntry(Messages.Reversing4CreationTool_title,
				Messages.Reversing4CreationTool_desc, null, null) {
		};
		entry.setId("createReversing4CreationTool"); //$NON-NLS-1$
		return entry;
	}

	/**
	 * @generated
	 */
	private ToolEntry createDirect5CreationTool() {
		NodeToolEntry entry = new NodeToolEntry(
				Messages.Direct5CreationTool_title,
				Messages.Direct5CreationTool_desc,
				Collections.singletonList(LayoutElementTypes.Reversing_2004));
		entry.setId("createDirect5CreationTool"); //$NON-NLS-1$
		entry.setSmallIcon(LayoutElementTypes
				.getImageDescriptor(LayoutElementTypes.Reversing_2004));
		entry.setLargeIcon(entry.getSmallIcon());
		return entry;
	}

	/**
	 * @generated
	 */
	private static class NodeToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> elementTypes;

		/**
		 * @generated
		 */
		private NodeToolEntry(String title, String description,
				List<IElementType> elementTypes) {
			super(title, description, null, null);
			this.elementTypes = elementTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeCreationTool(elementTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}

	/**
	 * @generated
	 */
	private static class LinkToolEntry extends ToolEntry {

		/**
		 * @generated
		 */
		private final List<IElementType> relationshipTypes;

		/**
		 * @generated
		 */
		private LinkToolEntry(String title, String description,
				List<IElementType> relationshipTypes) {
			super(title, description, null, null);
			this.relationshipTypes = relationshipTypes;
		}

		/**
		 * @generated
		 */
		public Tool createTool() {
			Tool tool = new UnspecifiedTypeConnectionTool(relationshipTypes);
			tool.setProperties(getToolProperties());
			return tool;
		}
	}
}
