#include "Common.h"
// Task: Display_Update_Task_IMPL

// Variables and constants
int cttm1_Display_Update_Task_IMPL = 0;
int ttm_Display_Update_Task_IMPL = 20;
BOOL sinc_flag_Display_Update_Task_IMPL = FALSE;
BOOL sdec_flag_Display_Update_Task_IMPL = FALSE;
const int priority_Display_Update_Task_IMPL = 5;


// Subroutines
void Display_Update_Task_IMPL()
{
	while(TRUE)
	{
		// [Internal] Timer information for repeating or periodic tasks
		double internalPeriodicStartTime = omp_get_wtime();
		double internalTimeDifference;
		
		// Translated code
		Shared_Object_IMPL_Get_Target_Temperature1(&cttm1_Display_Update_Task_IMPL);
		Envir1_IMPL_Sense_PressIncrease_Target_Temperature(&sinc_flag_Display_Update_Task_IMPL);
		if ((cttm1_Display_Update_Task_IMPL < Max) && (sinc_flag_Display_Update_Task_IMPL == TRUE))
		{
			ttm_Display_Update_Task_IMPL = (cttm1_Display_Update_Task_IMPL + 1);
			sinc_flag_Display_Update_Task_IMPL = FALSE;
		}
		else
		{
			sinc_flag_Display_Update_Task_IMPL = FALSE;
		}
		Envir1_IMPL_Sense_PressDecrease_Target_Temperature(&sdec_flag_Display_Update_Task_IMPL);
		if ((sdec_flag_Display_Update_Task_IMPL == TRUE) && (cttm1_Display_Update_Task_IMPL > Min))
		{
			ttm_Display_Update_Task_IMPL = ((cttm1_Display_Update_Task_IMPL) - 1);
			sdec_flag_Display_Update_Task_IMPL = FALSE;
		}
		else
		{
			sdec_flag_Display_Update_Task_IMPL = FALSE;
		}
		Shared_Object_IMPL_Set_Target_Temperature(ttm_Display_Update_Task_IMPL);
		Envir1_IMPL_Display_Target_Temperature(ttm_Display_Update_Task_IMPL);
		
		// [Internal] Code to monitor time between periodic tasks
		internalTimeDifference = omp_get_wtime() - internalPeriodicStartTime;
		__SLEEP(500 - (internalTimeDifference * 1000));
	}
}
