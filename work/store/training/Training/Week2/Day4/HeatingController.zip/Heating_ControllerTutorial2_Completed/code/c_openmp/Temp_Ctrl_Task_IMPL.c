#include "Common.h"
// Task: Temp_Ctrl_Task_IMPL

// Variables and constants
int avt_Temp_Ctrl_Task_IMPL = 0;
int cttm2_Temp_Ctrl_Task_IMPL = 0;
BOOL hsc_Temp_Ctrl_Task_IMPL = FALSE;
BOOL ota_Temp_Ctrl_Task_IMPL = FALSE;
int stm1_Temp_Ctrl_Task_IMPL = 0;
int stm2_Temp_Ctrl_Task_IMPL = 0;
const int priority_Temp_Ctrl_Task_IMPL = 5;


// Subroutines
void Temp_Ctrl_Task_IMPL()
{
	while(TRUE)
	{
		// [Internal] Timer information for repeating or periodic tasks
		double internalPeriodicStartTime = omp_get_wtime();
		double internalTimeDifference;
		
		// Translated code
		Envir1_IMPL_Sense_Temperatures(&stm1_Temp_Ctrl_Task_IMPL, &stm2_Temp_Ctrl_Task_IMPL);
		avt_Temp_Ctrl_Task_IMPL = ((stm1_Temp_Ctrl_Task_IMPL + stm2_Temp_Ctrl_Task_IMPL) / 2);
		Envir1_IMPL_Display_Current_Temperature(avt_Temp_Ctrl_Task_IMPL);
		Shared_Object_IMPL_Get_Target_Temperature2(&cttm2_Temp_Ctrl_Task_IMPL);
		if ((avt_Temp_Ctrl_Task_IMPL < cttm2_Temp_Ctrl_Task_IMPL))
		{
			hsc_Temp_Ctrl_Task_IMPL = TRUE;
		}
		else
		{
			hsc_Temp_Ctrl_Task_IMPL = FALSE;
		}
		Shared_Object_IMPL_Set_Heat_Source_State(hsc_Temp_Ctrl_Task_IMPL);
		Envir1_IMPL_Actuate_Heat_Source(hsc_Temp_Ctrl_Task_IMPL);
		if ((avt_Temp_Ctrl_Task_IMPL > Max))
		{
			ota_Temp_Ctrl_Task_IMPL = TRUE;
		}
		else
		{
			ota_Temp_Ctrl_Task_IMPL = FALSE;
		}
		Envir1_IMPL_Actuate_OverHeat_Alram(ota_Temp_Ctrl_Task_IMPL);
		printf("heat on =  %i\n", hsc_Temp_Ctrl_Task_IMPL);
		printf("ota on =  %i\n", ota_Temp_Ctrl_Task_IMPL);
		printf("avt temp : %i\n", avt_Temp_Ctrl_Task_IMPL);
		
		// [Internal] Code to monitor time between periodic tasks
		internalTimeDifference = omp_get_wtime() - internalPeriodicStartTime;
		__SLEEP(250 - (internalTimeDifference * 1000));
	}
}
