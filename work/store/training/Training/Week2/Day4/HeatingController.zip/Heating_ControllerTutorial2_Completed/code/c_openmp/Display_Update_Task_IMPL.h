#ifndef DISPLAY_UPDATE_TASK_IMPL_H
#define DISPLAY_UPDATE_TASK_IMPL_H
void Display_Update_Task_IMPL();
void __SLEEP(int period);
#endif

