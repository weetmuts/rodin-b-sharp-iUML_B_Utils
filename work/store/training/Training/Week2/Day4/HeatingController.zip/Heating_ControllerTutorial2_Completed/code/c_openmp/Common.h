#ifndef COMMON_H
#define COMMON_H
typedef int BOOL;
#define TRUE 1
#define FALSE 0
#include<stdio.h>
void __SLEEP(int period);
#include<omp.h>
extern const int Max ;

extern const int Min ;

#include "Shared_Object_IMPL.h"
#include "Temp_Ctrl_Task_IMPL.h"
#include "Heater_Monitor_Task_IMPL.h"
#include "Display_Update_Task_IMPL.h"
#include "Envir1_IMPL.h"
#endif

