#ifndef TEMP_CTRL_TASK_IMPL_H
#define TEMP_CTRL_TASK_IMPL_H
void Temp_Ctrl_Task_IMPL();
void __SLEEP(int period);
#endif

