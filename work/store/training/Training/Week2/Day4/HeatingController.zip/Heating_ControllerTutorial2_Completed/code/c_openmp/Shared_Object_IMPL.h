#ifndef SHARED_OBJECT_IMPL_H
#define SHARED_OBJECT_IMPL_H
void Shared_Object_IMPL_Get_Target_Temperature1(int *tm);
void Shared_Object_IMPL_Set_Target_Temperature(int tm);
void Shared_Object_IMPL_Get_Target_Temperature2(int *tm);
void Shared_Object_IMPL_Set_Heat_Source_State(BOOL state);
void Shared_Object_IMPL_Get_Stored_HeatSource(BOOL *state);
#endif

