// MainEntry: MainEntry
#include "Common.h"
// Global defns
const int Max = 45;

const int Min = 5;

int main (int argc, char *argv[])
{
	#pragma omp parallel sections
	{
		#pragma omp section
		{
			Temp_Ctrl_Task_IMPL();
		}
		#pragma omp section
		{
			Heater_Monitor_Task_IMPL();
		}
		#pragma omp section
		{
			Display_Update_Task_IMPL();
		}
		#pragma omp section
		{
			Envir1_IMPL();
		}
	}
}

