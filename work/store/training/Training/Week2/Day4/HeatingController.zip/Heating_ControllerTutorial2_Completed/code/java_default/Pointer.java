// Task: Pointer
package RodinCodeGeneration;
// Used to act as a pointer for out parameters in call-subroutines
public class Pointer<T>
{
	T value;
}
