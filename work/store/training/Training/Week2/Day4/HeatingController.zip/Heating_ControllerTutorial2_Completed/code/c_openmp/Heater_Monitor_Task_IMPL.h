#ifndef HEATER_MONITOR_TASK_IMPL_H
#define HEATER_MONITOR_TASK_IMPL_H
void Heater_Monitor_Task_IMPL();
void __SLEEP(int period);
#endif

