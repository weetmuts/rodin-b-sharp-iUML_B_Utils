#ifndef ENVIR1_IMPL_H
#define ENVIR1_IMPL_H
void Envir1_IMPL_Sense_PressIncrease_Target_Temperature(BOOL *state_inc);
void Envir1_IMPL_Sense_PressDecrease_Target_Temperature(BOOL *state_dec);
void Envir1_IMPL_Display_Target_Temperature(int tm_tt);
void Envir1_IMPL_Sense_Temperatures(int *t1, int *t2);
void Envir1_IMPL_Display_Current_Temperature(int tm_avt);
void Envir1_IMPL_Actuate_Heat_Source(BOOL state_hsc);
void Envir1_IMPL_Actuate_OverHeat_Alram(BOOL state_ota);
void Envir1_IMPL_Sense_Heater_Status(BOOL *state_hss);
void Envir1_IMPL_Actuate_NoHeat_Alarm(BOOL state_nha);
void Envir1_IMPL();
#endif

