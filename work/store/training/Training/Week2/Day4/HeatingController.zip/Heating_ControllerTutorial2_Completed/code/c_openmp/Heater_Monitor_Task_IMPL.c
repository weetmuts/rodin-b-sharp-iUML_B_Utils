#include "Common.h"
// Task: Heater_Monitor_Task_IMPL

// Variables and constants
BOOL hs1_Heater_Monitor_Task_IMPL = FALSE;
BOOL nha_Heater_Monitor_Task_IMPL = FALSE;
BOOL shs_Heater_Monitor_Task_IMPL = FALSE;
const int priority_Heater_Monitor_Task_IMPL = 5;


// Subroutines
void Heater_Monitor_Task_IMPL()
{
	while(TRUE)
	{
		// [Internal] Timer information for repeating or periodic tasks
		double internalPeriodicStartTime = omp_get_wtime();
		double internalTimeDifference;
		
		// Translated code
		Envir1_IMPL_Sense_Heater_Status(&shs_Heater_Monitor_Task_IMPL);
		Shared_Object_IMPL_Get_Stored_HeatSource(&hs1_Heater_Monitor_Task_IMPL);
		if ((hs1_Heater_Monitor_Task_IMPL != shs_Heater_Monitor_Task_IMPL))
		{
			nha_Heater_Monitor_Task_IMPL = TRUE;
		}
		else
		{
			nha_Heater_Monitor_Task_IMPL = FALSE;
		}
		Envir1_IMPL_Actuate_NoHeat_Alarm(nha_Heater_Monitor_Task_IMPL);
		
		// [Internal] Code to monitor time between periodic tasks
		internalTimeDifference = omp_get_wtime() - internalPeriodicStartTime;
		__SLEEP(250 - (internalTimeDifference * 1000));
	}
}
