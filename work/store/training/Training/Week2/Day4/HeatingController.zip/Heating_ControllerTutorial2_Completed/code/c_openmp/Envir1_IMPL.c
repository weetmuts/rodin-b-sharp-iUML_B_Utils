#include "Common.h"
// EnvironTask: Envir1_IMPL

// Variables and constants
BOOL inc_flag_Envir1_IMPL = FALSE;
BOOL dec_flag_Envir1_IMPL = FALSE;
int ts1_Envir1_IMPL = 0;
int ts2_Envir1_IMPL = 0;
BOOL hss_Envir1_IMPL = FALSE;
BOOL anha_Envir1_IMPL = FALSE;
int ttd_Envir1_IMPL = 20;
BOOL hsa_Envir1_IMPL = FALSE;
int ctd_Envir1_IMPL = 0;
BOOL aota_Envir1_IMPL = FALSE;
const int priority_Envir1_IMPL = 5;


// Subroutines
void Envir1_IMPL_Sense_PressIncrease_Target_Temperature(BOOL *state_inc)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			(*state_inc)= inc_flag_Envir1_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Sense_PressDecrease_Target_Temperature(BOOL *state_dec)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			(*state_dec)= dec_flag_Envir1_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Display_Target_Temperature(int tm_tt)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			ttd_Envir1_IMPL = tm_tt;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Sense_Temperatures(int *t1, int *t2)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			(*t1)= ts1_Envir1_IMPL ;
			(*t2)= ts2_Envir1_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Display_Current_Temperature(int tm_avt)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			ctd_Envir1_IMPL = tm_avt;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Actuate_Heat_Source(BOOL state_hsc)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			hsa_Envir1_IMPL = state_hsc;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Actuate_OverHeat_Alram(BOOL state_ota)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			aota_Envir1_IMPL = state_ota;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Sense_Heater_Status(BOOL *state_hss)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			(*state_hss)= hss_Envir1_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL_Actuate_NoHeat_Alarm(BOOL state_nha)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (ENVIR1_IMPL)
		{
			// Translated code
			anha_Envir1_IMPL = state_nha;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Envir1_IMPL()
{
	while(TRUE)
	{
		// [Internal] Timer information for repeating or periodic tasks
		double internalPeriodicStartTime = omp_get_wtime();
		double internalTimeDifference;
		if ((inc_flag_Envir1_IMPL == FALSE))
		{
			inc_flag_Envir1_IMPL = TRUE;
		}
		else
		{
			inc_flag_Envir1_IMPL = FALSE;
		}
		if ((dec_flag_Envir1_IMPL == FALSE))
		{
			dec_flag_Envir1_IMPL = TRUE;
		}
		else
		{
			dec_flag_Envir1_IMPL = FALSE;
		}
		hss_Envir1_IMPL = FALSE;
		ts1_Envir1_IMPL = (ts1_Envir1_IMPL + 1);
		printf("current temperature: %i\n", ctd_Envir1_IMPL);
		printf("overTemperature =  %i\n", aota_Envir1_IMPL);
		
		// [Internal] Code to monitor time between periodic tasks
		internalTimeDifference = omp_get_wtime() - internalPeriodicStartTime;
		__SLEEP(100 - (internalTimeDifference * 1000));
	}
}
