#include "Common.h"
// Protected: Shared_Object_IMPL

// Variables and constants
int ctm_Shared_Object_IMPL = 20;
BOOL shss_Shared_Object_IMPL = FALSE;
int cttm_Shared_Object_IMPL = 20;


// Subroutines
void Shared_Object_IMPL_Get_Target_Temperature1(int *tm)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (SHARED_OBJECT_IMPL)
		{
			// Translated code
			(*tm)= cttm_Shared_Object_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Shared_Object_IMPL_Set_Target_Temperature(int tm)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (SHARED_OBJECT_IMPL)
		{
			// Translated code
			cttm_Shared_Object_IMPL = tm;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Shared_Object_IMPL_Get_Target_Temperature2(int *tm)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (SHARED_OBJECT_IMPL)
		{
			// Translated code
			(*tm)= cttm_Shared_Object_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Shared_Object_IMPL_Set_Heat_Source_State(BOOL state)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (SHARED_OBJECT_IMPL)
		{
			// Translated code
			shss_Shared_Object_IMPL = state;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

void Shared_Object_IMPL_Get_Stored_HeatSource(BOOL *state)
{
	// [Internal] This will block until the guard has been met (no nice way of doing this in OpenMP 2.5)
	BOOL completed = FALSE; 	 // [Internal] Private to the thread by default
	while(!completed)
	{
		// [Internal] Try and get lock
		#pragma omp critical (SHARED_OBJECT_IMPL)
		{
			// Translated code
			(*state)= shss_Shared_Object_IMPL ;
			// [Internal] Set completed flag
			completed = TRUE;
		}
	}
}

