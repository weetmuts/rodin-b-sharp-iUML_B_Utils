package test2.popup.actions;

import java.util.Collections;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.NullProgressMonitor;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.AbstractEMFOperation;
import org.eclipse.jface.action.IAction;
import org.eclipse.jface.viewers.ISelection;
import org.eclipse.jface.viewers.IStructuredSelection;
import org.eclipse.swt.widgets.Shell;
import org.eclipse.ui.IActionDelegate;
import org.eclipse.ui.IObjectActionDelegate;
import org.eclipse.ui.IWorkbenchPart;
import org.eventb.core.IMachineRoot;
import org.eventb.emf.core.EventBObject;
import org.eventb.emf.core.machine.Event;
import org.eventb.emf.core.machine.Machine;
import org.eventb.emf.persistence.EMFRodinDB;
import org.rodinp.core.IInternalElement;

import test2.Activator;
import ac.soton.eventb.statemachines.Initial;
import ac.soton.eventb.statemachines.State;
import ac.soton.eventb.statemachines.Statemachine;
import ac.soton.eventb.statemachines.StatemachinesFactory;
import ac.soton.eventb.statemachines.Transition;


public class NewAction implements IObjectActionDelegate {

	private Shell shell;
	private IStructuredSelection selection;
	private Event initialisation =null;
	
	/**
	 * Constructor for Action1.
	 */
	public NewAction() {
		super();
	}

	/**
	 * @see IObjectActionDelegate#setActivePart(IAction, IWorkbenchPart)
	 */
	public void setActivePart(IAction action, IWorkbenchPart targetPart) {
		shell = targetPart.getSite().getShell();
	}

	/**
	 * @see IActionDelegate#run(IAction)
	 */
	public void run(IAction action) {

		Object el = selection.getFirstElement();
		if (el instanceof IMachineRoot) {
			EventBObject emfObject = EMFRodinDB.INSTANCE.loadElement((IInternalElement) el);
			if (emfObject instanceof Machine){
				Machine m = ((Machine)emfObject);
				
				EList<Event> events = m.getEvents();
				for (Event e : events){
					if ("INITIALISATION".equals(e.getName())){
						initialisation = e;
					}
				}
				
				if (initialisation != null){
					Statemachine sm = StatemachinesFactory.eINSTANCE.createStatemachine();
					sm.setName("mySm");
					//sm.setTranslation();
					Initial initialState = StatemachinesFactory.eINSTANCE.createInitial();
					sm.getNodes().add(initialState);
					
					State state1 = StatemachinesFactory.eINSTANCE.createState();
					state1.setName("state1");
					sm.getNodes().add(state1);
					
					Transition transition = StatemachinesFactory.eINSTANCE.createTransition();
					transition.getElaborates().add(initialisation);
					transition.setSource(initialState);
					transition.setTarget(state1);
					sm.getTransitions().add(transition);
					
					try {
						AddStatemachineCommand command = new AddStatemachineCommand(m.getURI(), sm);
						if (command.canExecute())
							command.execute(new NullProgressMonitor(), null);
					} catch (Exception e) {
						Activator.getDefault().logError("Creating statemachine failed", e);
					}

				}
			}
				
		}
	}
	
	
	/**
	 * EMF command for adding a statemachine to a machine.
	 *
	 */
	public class AddStatemachineCommand extends AbstractEMFOperation {

		private URI machineURI;
		private Statemachine statemachine;

		public AddStatemachineCommand(URI machineURI, Statemachine statemachine) {
			super(TransactionalEditingDomain.Factory.INSTANCE.createEditingDomain(EMFRodinDB.INSTANCE.getResourceSet()), "Add Statemachine");
			this.machineURI = machineURI;
			this.statemachine = statemachine;
		}

		@Override
		protected IStatus doExecute(IProgressMonitor monitor, IAdaptable info)
				throws ExecutionException {
			monitor.beginTask("Creating statemachine", IProgressMonitor.UNKNOWN);
			
			TransactionalEditingDomain editingDomain = getEditingDomain();
			
			try {
				Resource resource = editingDomain.getResourceSet().getResource(machineURI, true);
				
				if (resource != null && resource.isLoaded()) {
					Machine machine = (Machine) resource.getContents().get(0);
					machine.getExtensions().add(statemachine);
					resource.save(Collections.emptyMap());
				}
			} catch (Exception e) {
				return new Status(Status.ERROR, Activator.PLUGIN_ID, "Failed to add statemachine", e);
			} finally {
				monitor.done();
			}
			return Status.OK_STATUS;
		}

	}

	/**
	 * @see IActionDelegate#selectionChanged(IAction, ISelection)
	 */
	public void selectionChanged(IAction action, ISelection selection) {
		this.selection = (IStructuredSelection)selection;
	}

}
