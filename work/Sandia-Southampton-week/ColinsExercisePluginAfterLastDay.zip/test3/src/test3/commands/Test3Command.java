package test3.commands;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.eclipse.core.commands.ExecutionException;
import org.eclipse.core.resources.IWorkspaceRunnable;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IAdaptable;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.core.runtime.IStatus;
import org.eclipse.core.runtime.Status;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.common.util.WrappedException;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.EReference;
import org.eclipse.emf.ecore.EStructuralFeature;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.transaction.Transaction;
import org.eclipse.emf.transaction.TransactionalEditingDomain;
import org.eclipse.emf.workspace.AbstractEMFOperation;
import org.eventb.emf.core.EventBElement;
import org.rodinp.core.RodinCore;
import org.rodinp.core.RodinDBException;

import test3.Activator;

	//////////////////////Test 3 COMMAND//////////////////////////
	public class Test3Command extends AbstractEMFOperation {

		private EventBElement element;

		/**
		 * @param domain
		 * @param label
		 * @param affectedFiles
		 */
		public Test3Command(TransactionalEditingDomain editingDomain, EventBElement emfObject) {
			super(editingDomain, "Test3 Command", null);
			setOptions(Collections.singletonMap(Transaction.OPTION_UNPROTECTED, Boolean.TRUE));
			this.element = emfObject;
		}
		
		@Override
		public boolean canRedo(){
			return true;
		}

		@Override
		public boolean canUndo(){
			return true;
		}

		/* (non-Javadoc)
		 * @see org.eclipse.gmf.runtime.emf.commands.core.command.AbstractTransactionalCommand#doExecuteWithResult(org.eclipse.core.runtime.IProgressMonitor, org.eclipse.core.runtime.IAdaptable)
		 */
		@Override
		protected IStatus doExecute(IProgressMonitor monitor,
				IAdaptable info) throws ExecutionException {
			
			try {
				
				RodinCore.run(new IWorkspaceRunnable() {
					public void run(final IProgressMonitor monitor) throws CoreException{
								
						final List<Resource> modifiedResources = new ArrayList<Resource>();
						
						monitor.beginTask("",10);		
						monitor.setTaskName("Running Test 3 "); 

						// flush the command stack as this is unprotected and has no undo/redo
						//editingDomain.getCommandStack().flush();

						
						printNames(element);
								        

						
						monitor.worked(4);
						if (modifiedResources == null){
							
							//ErrorDialog errorDialog = new ErrorDialog(diagramEditor.getSite().getShell(), label, label, null, 0); 
							//should display a message here 
							//"Test3 Failed - see error log for details"
							
						}else{
							//try to save all the modified resources
					        monitor.subTask("starting to write resources");
							for (Resource resource : modifiedResources){
								try {
									resource.save(Collections.emptyMap());
									monitor.worked(1);
								} catch (IOException e) {
									//throw this as a CoreException
									throw new CoreException(
											new Status(Status.ERROR, Activator.PLUGIN_ID, "failed saving: "+resource, e));
								}					
							}
							

						}
					monitor.done();
					}
				},monitor);
				
				return Status.OK_STATUS;

			} catch (RodinDBException e) {
				//Activator.logError("Test3: ",e);
				return Status.OK_STATUS;
			} catch (WrappedException e) {
				//Activator.PLUGIN_ID.logError("Test3 exception", e);
				return Status.OK_STATUS;

			} finally {
				monitor.done();
			}
		}
		
		private void printNames(EventBElement element){
			for (EStructuralFeature feature : element.eClass().getEAllStructuralFeatures()){
				Object featureValue = element.eGet(feature);
				if (((EStructuralFeature)feature).isMany()){
					if (featureValue instanceof EList){
						for (Object object : (EList)featureValue ){
							if (object instanceof EObject){
								EObject eobject = (EObject)object;
								EStructuralFeature nameFeature = eobject.eClass().getEStructuralFeature("name");
								if (nameFeature != null) {
									Object nameValue = eobject.eGet(nameFeature);
									System.out.println(nameValue);
								}
							}
							if ((feature instanceof EReference && ((EReference)feature).isContainment() ) &&
									object instanceof EventBElement){
								printNames((EventBElement)object);
							}
						}
					}
				} else {
					if (featureValue instanceof EventBElement){
						printNames((EventBElement)featureValue);
					}
				}
				
			}
		}
	}